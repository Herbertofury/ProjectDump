Project Constellation Second Brain Website v0.5.1
63-project preservation base + current evidence overlay.
Source-controlled wiki: https://github.com/Herbertofury/ProjectDump/wiki
