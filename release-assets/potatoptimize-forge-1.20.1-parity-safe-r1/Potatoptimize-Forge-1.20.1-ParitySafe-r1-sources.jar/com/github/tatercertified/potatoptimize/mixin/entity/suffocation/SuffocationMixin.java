package com.github.tatercertified.potatoptimize.mixin.entity.suffocation;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(LivingEntity.class)
public abstract class SuffocationMixin extends Entity {
    public SuffocationMixin(EntityType<?> type, Level world) {
        super(type, world);
    }

    @Shadow public abstract boolean m_5830_();

    @Shadow protected float lastDamageTaken;

    @Shadow @Final public int defaultMaxHealth;

    @Redirect(method = "baseTick", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/LivingEntity;isInsideWall()Z"))
    private boolean redirectWallChecks(LivingEntity instance) {
        return ((f_19797_ % 10 == 0 && couldPossiblyBeHurt(1.0F))) && this.m_5830_();
    }

    @Unique
    public boolean couldPossiblyBeHurt(float amount) {
        return !((float) this.f_19802_ > (float) this.defaultMaxHealth / 2.0F) || !(amount <= this.lastDamageTaken);
    }
}
