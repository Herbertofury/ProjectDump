package com.github.tatercertified.potatoptimize.mixin.logic.shape;

import com.llamalad7.mixinextras.sugar.Local;
import it.unimi.dsi.fastutil.doubles.DoubleList;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Objects;
import net.minecraft.world.phys.shapes.IdenticalMerger;
import net.minecraft.world.phys.shapes.IndexMerger;
import net.minecraft.world.phys.shapes.IndirectMerger;
import net.minecraft.world.phys.shapes.Shapes;

@Mixin(Shapes.class)
public abstract class VoxelShapesMixin {
    @Shadow
    protected static native IndexMerger createListPair(int size, DoubleList first, DoubleList second, boolean includeFirst, boolean includeSecond);

    private static IndexMerger createListPairOptimized(int size, DoubleList first, DoubleList second, boolean includeFirst, boolean includeSecond) {
        if (first.getDouble(0) == Double.NEGATIVE_INFINITY && first.getDouble(first.size() - 1) == Double.POSITIVE_INFINITY) {
            return new IndirectMerger(first, second, includeFirst, includeSecond);
        }
        return createListPair(size, first, second, includeFirst, includeSecond);
    }

    @Redirect(method = "combine", at = @At(value = "INVOKE", target = "Lnet/minecraft/util/shape/VoxelShapes;createListPair(ILit/unimi/dsi/fastutil/doubles/DoubleList;Lit/unimi/dsi/fastutil/doubles/DoubleList;ZZ)Lnet/minecraft/util/shape/PairList;"))
    private static IndexMerger redirectListPair1(int size, DoubleList first, DoubleList second, boolean includeFirst, boolean includeSecond) {
        return createListPairOptimized(size, first, second, includeFirst, includeSecond);
    }

    @Redirect(method = "matchesAnywhere(Lnet/minecraft/util/shape/VoxelShape;Lnet/minecraft/util/shape/VoxelShape;Lnet/minecraft/util/function/BooleanBiFunction;)Z", at = @At(value = "INVOKE", target = "Lnet/minecraft/util/shape/VoxelShapes;createListPair(ILit/unimi/dsi/fastutil/doubles/DoubleList;Lit/unimi/dsi/fastutil/doubles/DoubleList;ZZ)Lnet/minecraft/util/shape/PairList;"))
    private static IndexMerger redirectListPair2(int size, DoubleList first, DoubleList second, boolean includeFirst, boolean includeSecond) {
        return createListPairOptimized(size, first, second, includeFirst, includeSecond);
    }

    @Inject(method = "createListPair", at = @At(value = "INVOKE", target = "Lit/unimi/dsi/fastutil/doubles/DoubleList;getDouble(I)D", ordinal = 0, shift = At.Shift.BEFORE, remap = false), cancellable = true)
    private static void injectCreatePairList(int size, DoubleList first, DoubleList second, boolean includeFirst, boolean includeSecond, CallbackInfoReturnable<IndexMerger> cir, @Local(ordinal = 0) int i, @Local(ordinal = 0) int j) {
        if (i == j && Objects.equals(first, second)) {
            if (first instanceof IdenticalMerger) {
                cir.setReturnValue((IndexMerger) first);
            } else if (second instanceof IdenticalMerger) {
                cir.setReturnValue((IndexMerger) second);
            }
            cir.setReturnValue(new IdenticalMerger(first));
        }
    }

    @Inject(method = "createListPair", at = @At(value = "RETURN"), cancellable = true)
    private static void redirectReturn(int size, DoubleList first, DoubleList second, boolean includeFirst, boolean includeSecond, CallbackInfoReturnable<IndexMerger> cir) {
        cir.setReturnValue(new IndirectMerger(first, second, includeFirst, includeSecond));
    }
}
