package com.github.tatercertified.potatoptimize.mixin.unstream.player_movement;

import net.minecraft.core.BlockPos;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;

@Mixin(ServerGamePacketListenerImpl.class)
public class PlayerMovementMixin {
    /**
     * @author Maity (stale Lithium PR)
     * @reason Remove streams
     */
    @Overwrite
    private boolean isEntityOnAir(Entity entity) {
        AABB box = entity.m_20191_().m_82400_(0.0625).m_82363_(0.0, -0.55, 0.0);

        int minX = Mth.m_14107_(box.f_82288_);
        int minY = Mth.m_14107_(box.f_82289_);
        int minZ = Mth.m_14107_(box.f_82290_);
        int maxX = Mth.m_14107_(box.f_82291_);
        int maxY = Mth.m_14107_(box.f_82292_);
        int maxZ = Mth.m_14107_(box.f_82293_);

        Level world = entity.m_9236_();
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();

        for (int x = minX; x <= maxX; ++x) {
            for (int y = minY; y <= maxY; ++y) {
                for (int z = minZ; z <= maxZ; ++z) {
                    pos.m_122178_(x, y, z);

                    if (!world.m_8055_(pos).m_60795_()) {
                        return false;
                    }
                }
            }
        }

        return true;
    }
}
