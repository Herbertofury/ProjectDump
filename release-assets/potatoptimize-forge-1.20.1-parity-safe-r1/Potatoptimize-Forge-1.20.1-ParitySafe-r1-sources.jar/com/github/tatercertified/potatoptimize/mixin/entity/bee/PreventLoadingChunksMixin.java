package com.github.tatercertified.potatoptimize.mixin.entity.bee;

import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.animal.Bee;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;


/**
 * Credit to PaperMC patch #0363
 */
@Mixin(Bee.class)
public abstract class PreventLoadingChunksMixin extends Entity {

    @Shadow @Nullable public abstract BlockPos getHivePos();

    public PreventLoadingChunksMixin(EntityType<?> type, Level world) {
        super(type, world);
    }

    @Inject(method = "isHiveNearFire", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/World;getBlockEntity(Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/entity/BlockEntity;"), cancellable = true)
    private void cancelIfNotLoaded(CallbackInfoReturnable<Boolean> cir) {
        if (this.isChunkNotNear(this.m_20183_(), this.getHivePos()) || !this.m_9236_().m_46805_(this.getHivePos())) {
            cir.setReturnValue(false);
        }
    }

    @Inject(method = "doesHiveHaveSpace", at = @At("HEAD"), cancellable = true)
    private void cancelIfNotLoaded(BlockPos pos, CallbackInfoReturnable<Boolean> cir) {
        if (this.isChunkNotNear(this.m_20183_(), pos) || !this.m_9236_().m_46805_(pos)) {
            cir.setReturnValue(false);
        }
    }

    @Redirect(method = "isHiveValid", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/passive/BeeEntity;isTooFar(Lnet/minecraft/util/math/BlockPos;)Z"))
    private boolean cancelIfNotLoaded(Bee instance, BlockPos pos) {
        return this.isChunkNotNear(this.m_20183_(), pos) || !this.m_9236_().m_46805_(pos);
    }

    // TODO Make this work with ChunkQuery
    @Unique
    private boolean isChunkNotNear(BlockPos pos1, BlockPos pos2) {
        if (pos1 == null || pos2 == null) {
            return false;
        }
        return !pos1.m_123314_(pos2, 32);
    }
}
