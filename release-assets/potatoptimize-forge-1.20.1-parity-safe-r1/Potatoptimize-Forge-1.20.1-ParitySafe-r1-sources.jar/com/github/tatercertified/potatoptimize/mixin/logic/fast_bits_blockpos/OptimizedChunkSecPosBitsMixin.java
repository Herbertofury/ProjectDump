package com.github.tatercertified.potatoptimize.mixin.logic.fast_bits_blockpos;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;

import java.util.stream.Stream;
import net.minecraft.core.BlockPos;
import net.minecraft.core.SectionPos;
import net.minecraft.core.Vec3i;
import net.minecraft.world.level.ChunkPos;

@Mixin(SectionPos.class)
public abstract class OptimizedChunkSecPosBitsMixin extends Vec3i {
    @Shadow
    public static Stream<SectionPos> stream(int minX, int minY, int minZ, int maxX, int maxY, int maxZ) {
        return null;
    }

    public OptimizedChunkSecPosBitsMixin(int x, int y, int z) {
        super(x, y, z);
    }

    /**
     * @author QPCrummer
     * @reason Inline
     */
    @Overwrite
    public static SectionPos from(BlockPos pos) {
        return ChunkSectionPosAccessor.invokeChunkSectionPos(pos.m_123341_() >> 4, pos.m_123342_() >> 4, pos.m_123343_() >> 4);
    }

    /**
     * @author QPCrummer
     * @reason Inline
     */
    @Overwrite
    public static SectionPos from(long packed) {
        return ChunkSectionPosAccessor.invokeChunkSectionPos((int) (packed >> 42), (int) (packed << 44 >> 44), (int) (packed << 22 >> 42));
    }

    /**
     * @author QPCrummer
     * @reason Inline
     */
    @Overwrite
    public static long offset(long packed, int x, int y, int z) {
        return (((long) ((int) (packed >> 42) + x) & 4194303L) << 42) | (((long) ((int) (packed << 44 >> 44) + y) & 1048575L)) | (((long) ((int) (packed << 22 >> 42) + z) & 4194303L) << 20);
    }

    /**
     * @author QPCrummer
     * @reason Inline
     */
    @Overwrite
    public static short packLocal(BlockPos pos) {
        return (short) ((pos.m_123341_() & 15) << 8 | (pos.m_123343_() & 15) << 4 | pos.m_123342_() & 15);
    }

    /**
     * @author QPCrummer
     * @reason Inline
     */
    @Overwrite
    public int getMinX() {
        return this.m_123341_() << 4;
    }

    /**
     * @author QPCrummer
     * @reason Inline
     */
    @Overwrite
    public int getMinY() {
        return this.m_123342_() << 4;
    }

    /**
     * @author QPCrummer
     * @reason Inline
     */
    @Overwrite
    public int getMinZ() {
        return this.m_123343_() << 4;
    }

    /**
     * @author QPCrummer
     * @reason Inline
     */
    @Overwrite
    public static long fromBlockPos(long blockPos) {
        return (((long) (int) (blockPos >> 42) & 4194303L) << 42) | (((long) (int) ((blockPos << 52) >> 56) & 1048575L)) | (((long) (int) ((blockPos << 26) >> 42) & 4194303L) << 20);
    }

    /**
     * @author QPCrummer
     * @reason Inline
     */
    @Overwrite
    public static long asLong(int x, int y, int z) {
        return (((long) x & 4194303L) << 42) | (((long) y & 1048575L)) | (((long) z & 4194303L) << 20);
    }

    /**
     * @author QPCrummer
     * @reason Inline
     */
    @Overwrite
    public long asLong() {
        return (((long) m_123341_() & 4194303L) << 42) | (((long) m_123342_() & 1048575L)) | (((long) m_123343_() & 4194303L) << 20);
    }

    /**
     * @author QPCrummer
     * @reason Inline
     */
    @Overwrite
    public static Stream<SectionPos> stream(SectionPos center, int radius) {
        return stream(center.m_123341_() - radius, center.m_123342_() - radius, center.m_123343_() - radius, center.m_123341_() + radius, center.m_123342_() + radius, center.m_123343_() + radius);
    }

    /**
     * @author QPCrummer
     * @reason Inline while preserving vanilla-provided vertical bounds.
     */
    @Overwrite
    public static Stream<SectionPos> stream(ChunkPos center, int radius, int minY, int maxY) {
        return stream(center.f_45578_ - radius, minY, center.f_45579_ - radius, center.f_45578_ + radius, maxY, center.f_45579_ + radius);
    }

}
