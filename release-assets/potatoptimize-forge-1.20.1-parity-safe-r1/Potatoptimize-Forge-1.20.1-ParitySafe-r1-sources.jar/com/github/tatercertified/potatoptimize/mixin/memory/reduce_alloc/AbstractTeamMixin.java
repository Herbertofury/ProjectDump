package com.github.tatercertified.potatoptimize.mixin.memory.reduce_alloc;

import com.github.tatercertified.potatoptimize.utils.Constants;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;

import java.util.Map;
import net.minecraft.world.scores.Team;

@Mixin(Team.Visibility.class)
public class AbstractTeamMixin {
    @Shadow @Final private static Map<String, Team.Visibility> VISIBILITY_RULES;

    /**
     * @author QPCrummer
     * @reason Reduce Allocations
     */
    @Overwrite
    public static String[] getKeys() {
        return VISIBILITY_RULES.keySet().toArray(Constants.emptyStringArray);
    }
}
