package com.github.tatercertified.potatoptimize.mixin.block_entity.chest_chunk_loading;

import com.llamalad7.mixinextras.sugar.Local;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.function.BiPredicate;
import java.util.function.Function;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.DoubleBlockCombiner;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.DirectionProperty;

/**
 * Credit to PaperMC patch #0331
 */
@Mixin(DoubleBlockCombiner.class)
public class NoChestChunkLoadingMixin {
    @Redirect(method = "toPropertySource", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/WorldAccess;getBlockState(Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/BlockState;"))
    private static <S extends BlockEntity> BlockState noChunkLoading(LevelAccessor instance, BlockPos pos, @Local(ordinal = 0) S blockEntity) {
        if (instance.m_46805_(pos)) {
            return instance.m_8055_(pos);
        }
        return null;
    }

    @Inject(method = "toPropertySource", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/WorldAccess;getBlockState(Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/BlockState;", shift = At.Shift.AFTER), cancellable = true)
    private static <S extends BlockEntity> void checkIfNull(BlockEntityType<S> blockEntityType, Function<BlockState, DoubleBlockCombiner.BlockType> typeMapper, Function<BlockState, Direction> function, DirectionProperty directionProperty, BlockState state, LevelAccessor world, BlockPos pos, BiPredicate<LevelAccessor, BlockPos> fallbackTester, CallbackInfoReturnable<DoubleBlockCombiner.NeighborCombineResult<S>> cir, @Local(ordinal = 0) BlockState blockState, @Local(ordinal = 0) S blockEntity) {
        if (blockState == null) {
            cir.setReturnValue(new DoubleBlockCombiner.NeighborCombineResult.Single<>(blockEntity));
        }
    }
}
