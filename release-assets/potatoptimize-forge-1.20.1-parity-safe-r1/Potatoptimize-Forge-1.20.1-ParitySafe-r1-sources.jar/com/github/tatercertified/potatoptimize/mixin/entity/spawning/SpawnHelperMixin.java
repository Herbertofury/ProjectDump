package com.github.tatercertified.potatoptimize.mixin.entity.spawning;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Objects;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.NaturalSpawner;
import net.minecraft.world.level.StructureManager;
import net.minecraft.world.level.chunk.ChunkAccess;

@Mixin(NaturalSpawner.class)
public class SpawnHelperMixin {
    @Inject(method = "shouldUseNetherFortressSpawns", at = @At("HEAD"), cancellable = true)
    private static void checkDimension(BlockPos pos, ServerLevel world, MobCategory spawnGroup, StructureManager structureAccessor, CallbackInfoReturnable<Boolean> cir) {
        if (world.m_46472_() != ServerLevel.f_46429_) {
            cir.setReturnValue(false);
        }
    }

    /**
     * @author QPCrummer
     * @reason There is no reason to check distance to the player twice
     */
    @Overwrite
    private static boolean isAcceptableSpawnPosition(ServerLevel world, ChunkAccess chunk, BlockPos.MutableBlockPos pos, double squaredDistance) {
        if (squaredDistance <= 576.0) {
            return false;
        }
        return Objects.equals(new ChunkPos(pos), chunk.m_7697_()) || world.m_201918_(pos);
    }
}
