package com.github.tatercertified.potatoptimize.mixin.world.farmland;

import net.minecraft.core.BlockPos;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.FarmBlock;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.material.FluidState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;

/**
 * Credit to PaperMC patch #0682 and EinS4ckZwiebeln
 */
@Mixin(FarmBlock.class)
public abstract class FarmlandBlockMixin {

    /**
     * @author QPCrummer
     * @reason Optimize FarlandBlock nearby water lookup
     */
    @Overwrite
    private static boolean isWaterNearby(LevelReader world, BlockPos pos) {
        int posX = pos.m_123341_();
        int posY = pos.m_123342_();
        int posZ = pos.m_123343_();

        for (int dz = -4; dz <= 4; ++dz) {
            int z = dz + posZ;
            for (int dx = -4; dx <= 4; ++dx) {
                int x = posX + dx;
                for (int dy = 0; dy <= 1; ++dy) {
                    ChunkAccess chunk = world.m_6325_(x >> 4, z >> 4);
                    FluidState fluid = chunk.m_8055_(new BlockPos(x, dy + posY, z)).m_60819_();
                    if (fluid.m_205070_(FluidTags.f_13131_)) return true;
                }
            }
        }
        return false;
    }
}
