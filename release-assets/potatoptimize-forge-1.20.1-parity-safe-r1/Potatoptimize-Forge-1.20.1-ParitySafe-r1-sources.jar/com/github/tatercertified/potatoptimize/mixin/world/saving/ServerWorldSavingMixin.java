package com.github.tatercertified.potatoptimize.mixin.world.saving;

import com.github.tatercertified.potatoptimize.utils.interfaces.AsyncChunkManagerInterface;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerChunkCache;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.dimension.end.EndDragonFight;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(ServerLevel.class)
public abstract class ServerWorldSavingMixin {

    @Shadow @Nullable private EndDragonFight enderDragonFight;

    @Shadow @Final private MinecraftServer server;

    @Shadow public abstract ServerChunkCache getChunkManager();

    @Unique
    private void saveLevel(boolean async) {
        if (this.enderDragonFight != null) {
            this.server.m_129910_().m_5915_(this.enderDragonFight.m_289745_());
        }

        ((AsyncChunkManagerInterface)this.getChunkManager().m_8483_()).save(async);
    }

    @Redirect(method = "save", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/world/ServerWorld;saveLevel()V"))
    private void redirectToAsync(ServerLevel instance) {
        //TODO Figure out what "close" is in
        this.saveLevel(true);
    }
}
