package com.github.tatercertified.potatoptimize.mixin.item.treasure_map_lookup;

import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.item.MapItem;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/**
 * Credit to PaperMC patch #0406
 */
@Mixin(MapItem.class)
public class FilledMapItemMixin {

    @Redirect(method = "fillExplorationMap", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/world/ServerWorld;getBiome(Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/registry/entry/RegistryEntry;"))
    private static Holder getBiomeRedirect(ServerLevel instance, BlockPos pos, @Local(ordinal = 0) int l, @Local(ordinal = 0) int o, @Local(ordinal = 0) int i, @Local(ordinal = 0) int m, @Local(ordinal = 0) int n) {
        return instance.m_203675_((l + o) * i, 0, (m + n) * i);
    }
}
