package com.github.tatercertified.potatoptimize.mixin.unstream.nearest_item;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.EntitySelector;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.Brain;
import net.minecraft.world.entity.ai.memory.MemoryModuleType;
import net.minecraft.world.entity.ai.sensing.PlayerSensor;
import net.minecraft.world.entity.ai.sensing.Sensor;
import net.minecraft.world.entity.player.Player;

/**
 * Credit to PaperMC patch #0555
 */
@Mixin(PlayerSensor.class)
public class NearestPlayersSensorMixin {
    /**
     * @author QPCrummer
     * @reason Remove Streams
     */
    @Overwrite
    public void sense(ServerLevel world, LivingEntity entity) {
        List<Player> players = new ArrayList<>(world.m_6907_());
        players.removeIf(player -> !EntitySelector.f_20408_.test(player) || !entity.m_19950_(player, 16.0D));
        players.sort(Comparator.comparingDouble(entity::m_20270_));
        Brain<?> brain = entity.m_6274_();
        brain.m_21879_(MemoryModuleType.f_26367_, players);

        Player nearest = null, nearestTargetable = null;
        for (Player player : players) {
            if (Sensor.m_26803_(entity, player)) {
                if (nearest == null) nearest = player;
                if (Sensor.m_148312_(entity, player)) {
                    nearestTargetable = player;
                    break;
                }
            }
        }
        brain.m_21879_(MemoryModuleType.f_26368_, nearest);
        brain.m_21879_(MemoryModuleType.f_148206_, nearestTargetable);
    }
}
