package com.github.tatercertified.potatoptimize.mixin.memory.reduce_alloc;

import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Map;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeMap;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;

// Credit Gale patch #0040
@Mixin(AttributeMap.class)
public abstract class AttributeContainerMixin {
    @Shadow @Final private AttributeSupplier fallback;

    @Shadow protected abstract void updateTrackedStatus(AttributeInstance instance);

    @Shadow @Final private Map<Attribute, AttributeInstance> custom;
    @Unique
    @Final
    @Mutable
    private java.util.function.Function<Attribute, AttributeInstance> createInstance;

    @Inject(method = "<init>", at = @At("TAIL"))
    private void injectAttribute(AttributeSupplier defaultAttributes, CallbackInfo ci) {
        this.createInstance = attribute -> this.fallback.m_22250_(this::updateTrackedStatus, attribute);
    }

    /**
     * @author QPCrummer
     * @reason Reduce allocations
     */
    @Overwrite
    public @Nullable AttributeInstance getCustomInstance(Attribute attribute) {
        return this.custom.computeIfAbsent(attribute, this.createInstance);
    }
}
