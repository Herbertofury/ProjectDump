package com.github.tatercertified.potatoptimize.mixin.world.explosion;

import com.llamalad7.mixinextras.sugar.Local;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.phys.AABB;

/**
 * Credit to PaperMC patch #0334 and patch #0039
 */
@Mixin(Explosion.class)
public class OptimizedExplosionMixin {
    @Shadow @Final private Level world;

    public OptimizedExplosionMixin() {
    }

    @Redirect(method = "collectBlocksAndDamageEntities", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/World;getFluidState(Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/fluid/FluidState;"))
    private FluidState redirectFluidState(Level instance, BlockPos pos, @Local(ordinal = 0) BlockState blockState) {
        return blockState.m_60819_();
    }

    @Redirect(method = "collectBlocksAndDamageEntities", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/World;getOtherEntities(Lnet/minecraft/entity/Entity;Lnet/minecraft/util/math/Box;)Ljava/util/List;"))
    private List<Entity> optimizeGetEntities(Level instance, Entity entity, AABB box, @Local(ordinal = 0) int k, @Local(ordinal = 0) int r, @Local(ordinal = 0) int t, @Local(ordinal = 0) int l, @Local(ordinal = 0) int s, @Local(ordinal = 0) int u) {
        return this.world.m_6249_(entity, new AABB(k, r, t, l, s, u), (com.google.common.base.Predicate<Entity>) entity1 -> entity1.m_6084_() && !entity1.m_5833_());
    }
}
