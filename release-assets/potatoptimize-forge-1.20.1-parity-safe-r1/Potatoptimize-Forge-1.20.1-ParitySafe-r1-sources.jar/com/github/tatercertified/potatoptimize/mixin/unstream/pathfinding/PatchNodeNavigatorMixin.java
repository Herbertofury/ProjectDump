package com.github.tatercertified.potatoptimize.mixin.unstream.pathfinding;

import com.google.common.collect.Lists;
import net.minecraft.core.BlockPos;
import net.minecraft.entity.ai.pathing.*;
import net.minecraft.util.profiling.ProfilerFiller;
import net.minecraft.util.profiling.metrics.MetricCategory;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.level.PathNavigationRegion;
import net.minecraft.world.level.pathfinder.BinaryHeap;
import net.minecraft.world.level.pathfinder.Node;
import net.minecraft.world.level.pathfinder.NodeEvaluator;
import net.minecraft.world.level.pathfinder.Path;
import net.minecraft.world.level.pathfinder.PathFinder;
import net.minecraft.world.level.pathfinder.Target;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.*;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Credit PaperMC patch #0485
 */
@Mixin(PathFinder.class)
public abstract class PatchNodeNavigatorMixin {
    @Shadow
    @Final
    private BinaryHeap minHeap;

    @Shadow
    @Final
    private NodeEvaluator pathNodeMaker;

    @Shadow
    @Final
    private int range;

    @Shadow
    @Final
    private Node[] successors;

    @Shadow
    protected abstract float getDistance(Node a, Node b);

    @Shadow protected abstract Path createPath(Node endNode, BlockPos target, boolean reachesTarget);

    /**
     * @author QPCrummer
     * @reason Remove Streams
     */
    @Overwrite
    public @Nullable Path findPathToAny(PathNavigationRegion world, Mob mob, Set<BlockPos> positions, float followRange, int distance, float rangeMultiplier) {
        this.minHeap.m_77081_();
        this.pathNodeMaker.m_6028_(world, mob);
        Node pathNode = this.pathNodeMaker.m_7171_();
        if (pathNode == null) {
            return null;
        } else {
            List<Map.Entry<Target, BlockPos>> map = Lists.newArrayList();
            for (BlockPos pos : positions) {
                map.add(new java.util.AbstractMap.SimpleEntry<>(this.pathNodeMaker.m_7568_(pos.m_123341_(), pos.m_123342_(), pos.m_123343_()), pos));
            }
            Path path = this.findPathToAny(world.m_151625_(), pathNode, map, followRange, distance, rangeMultiplier);
            this.pathNodeMaker.m_6802_();
            return path;
        }
    }

    @Unique
    private Path findPathToAny(ProfilerFiller profiler, Node startNode, List<Map.Entry<Target, BlockPos>> positions, float followRange, int distance, float rangeMultiplier) {
        profiler.m_6180_("find_path");
        profiler.m_142259_(MetricCategory.PATH_FINDING);
        startNode.f_77275_ = 0.0F;
        startNode.f_77276_ = this.calculateDistances(startNode, positions);
        startNode.f_77277_ = startNode.f_77276_;
        this.minHeap.m_77081_();
        this.minHeap.m_77084_(startNode);
        int i = 0;
        List<Map.Entry<Target, BlockPos>> entryList = Lists.newArrayListWithExpectedSize(positions.size());
        int j = (int) ((float) this.range * rangeMultiplier);

        while (!this.minHeap.m_77092_()) {
            ++i;
            if (i >= j) {
                break;
            }

            Node pathNode = this.minHeap.m_77091_();
            pathNode.f_77279_ = true;

            for (final Map.Entry<Target, BlockPos> entry : positions) {
                Target target = entry.getKey();
                if (pathNode.m_77304_(target) <= (float) distance) {
                    target.m_77509_();
                    entryList.add(entry);
                }
            }

            if (!entryList.isEmpty()) {
                break;
            }

            if (!(pathNode.m_77293_(startNode) >= followRange)) {
                int k = this.pathNodeMaker.m_6065_(this.successors, pathNode);

                for (int l = 0; l < k; ++l) {
                    Node pathNode2 = this.successors[l];
                    float f = this.getDistance(pathNode, pathNode2);
                    pathNode2.f_77280_ = pathNode.f_77280_ + f;
                    float g = pathNode.f_77275_ + f + pathNode2.f_77281_;
                    if (pathNode2.f_77280_ < followRange && (!pathNode2.m_77303_() || g < pathNode2.f_77275_)) {
                        pathNode2.f_77278_ = pathNode;
                        pathNode2.f_77275_ = g;
                        pathNode2.f_77276_ = this.calculateDistances(pathNode2, positions) * 1.5F;
                        if (pathNode2.m_77303_()) {
                            this.minHeap.m_77086_(pathNode2, pathNode2.f_77275_ + pathNode2.f_77276_);
                        } else {
                            pathNode2.f_77277_ = pathNode2.f_77275_ + pathNode2.f_77276_;
                            this.minHeap.m_77084_(pathNode2);
                        }
                    }
                }
            }
        }

        Path best = null;
        boolean entryListIsEmpty = entryList.isEmpty();
        Comparator<Path> comparator = entryListIsEmpty ? Comparator.comparingInt(Path::m_77398_)
                : Comparator.comparingDouble(Path::m_77407_).thenComparingInt(Path::m_77398_);
        for (Map.Entry<Target, BlockPos> entry : entryListIsEmpty ? positions : entryList) {
            Path path = this.createPath(entry.getKey().m_77508_(), entry.getValue(), !entryListIsEmpty);
            if (best == null || comparator.compare(path, best) < 0)
                best = path;
        }
        return best;
    }

    @Unique
    private float calculateDistances(Node node, List<Map.Entry<Target, BlockPos>> targets) {
        float f = Float.MAX_VALUE;

        float g;
        for (Map.Entry<Target, BlockPos> targetPathNodeBlockPosEntry : targets) {
            final Target target = targetPathNodeBlockPosEntry.getKey();
            g = node.m_77293_(target);
            target.m_77503_(g, node);
        }

        return f;
    }
}
