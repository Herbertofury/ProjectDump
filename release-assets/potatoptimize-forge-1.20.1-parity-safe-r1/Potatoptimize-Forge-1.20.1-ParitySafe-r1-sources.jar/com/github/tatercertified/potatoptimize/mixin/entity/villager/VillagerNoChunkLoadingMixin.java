package com.github.tatercertified.potatoptimize.mixin.entity.villager;

import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.behavior.SleepInBed;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Credit to PaperMC patch #0326
 */
@Mixin(SleepInBed.class)
public class VillagerNoChunkLoadingMixin {
    @Redirect(method = "shouldRun", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/world/ServerWorld;getBlockState(Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/BlockState;"))
    private BlockState noChunkLoading(ServerLevel instance, BlockPos pos) {
        return instance.m_46805_(pos) ? instance.m_8055_(pos) : null;
    }

    @Inject(method = "shouldRun", at = @At(value = "INVOKE", target = "Lnet/minecraft/util/math/GlobalPos;getPos()Lnet/minecraft/util/math/BlockPos;", ordinal = 1), cancellable = true)
    private void checkForNull(ServerLevel world, LivingEntity entity, CallbackInfoReturnable<Boolean> cir, @Local(ordinal = 0) BlockState blockState) {
        if (blockState == null) {
            cir.setReturnValue(false);
        }
    }
}
