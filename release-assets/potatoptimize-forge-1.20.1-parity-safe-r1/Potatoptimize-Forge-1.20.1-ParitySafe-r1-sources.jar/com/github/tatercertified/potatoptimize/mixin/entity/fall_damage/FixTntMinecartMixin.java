package com.github.tatercertified.potatoptimize.mixin.entity.fall_damage;

import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.vehicle.MinecartTNT;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.gameevent.GameEvent;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(MinecartTNT.class)
public abstract class FixTntMinecartMixin extends Entity {

    public FixTntMinecartMixin(EntityType<?> type, Level world) {
        super(type, world);
    }

    @Override
    protected void m_7840_(double heightDifference, boolean onGround, BlockState state, BlockPos landedPosition) {
        if (onGround) {
            if (this.f_19789_ > 0.0f) {
                state.m_60734_().m_142072_(this.m_9236_(), state, landedPosition, this, this.f_19789_);
                this.m_9236_().m_214171_(GameEvent.f_157770_, this.m_20182_(), GameEvent.Context.m_223719_(this, this.f_285638_.map(blockPos -> this.m_9236_().m_8055_(blockPos)).orElse(state)));
            }
            this.m_183634_();
        } else if (heightDifference < 0.0) {
            this.f_19789_ -= (float)heightDifference;
        }
    }
}
