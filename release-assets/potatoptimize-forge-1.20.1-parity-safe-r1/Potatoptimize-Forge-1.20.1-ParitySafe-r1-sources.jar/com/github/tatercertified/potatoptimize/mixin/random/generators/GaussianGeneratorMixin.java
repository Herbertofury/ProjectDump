package com.github.tatercertified.potatoptimize.mixin.random.generators;

import com.github.tatercertified.potatoptimize.utils.random.ThreadLocalRandomImpl;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.levelgen.MarsagliaPolarGaussian;
import org.spongepowered.asm.mixin.*;

@Mixin(MarsagliaPolarGaussian.class)
public class GaussianGeneratorMixin {
    @Final @Shadow @Mutable
    public final RandomSource baseRandom = new ThreadLocalRandomImpl();

    @Shadow private boolean hasNextGaussian;

    @Shadow private double nextNextGaussian;

    /**
     * @author QPCrummer
     * @reason Faster Gaussian Implementation
     */
    @Overwrite
    public double next() {
        if (this.hasNextGaussian) {
            this.hasNextGaussian = false;
            return this.nextNextGaussian;
        }
        this.nextNextGaussian = this.baseRandom.m_188583_();
        this.hasNextGaussian = true;
        return this.nextNextGaussian;
    }
}
