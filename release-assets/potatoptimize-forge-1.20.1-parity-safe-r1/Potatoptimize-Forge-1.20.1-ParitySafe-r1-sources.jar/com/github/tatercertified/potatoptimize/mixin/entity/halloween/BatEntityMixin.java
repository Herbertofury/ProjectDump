package com.github.tatercertified.potatoptimize.mixin.entity.halloween;

import com.github.tatercertified.potatoptimize.Potatoptimize;
import com.github.tatercertified.potatoptimize.utils.interfaces.IsHalloweenInterface;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ambient.AmbientCreature;
import net.minecraft.world.entity.ambient.Bat;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(Bat.class)
public abstract class BatEntityMixin extends AmbientCreature {


    protected BatEntityMixin(EntityType<? extends AmbientCreature> entityType, Level world) {
        super(entityType, world);
    }

    @Redirect(method = "canSpawn", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/passive/BatEntity;isTodayAroundHalloween()Z"))
    private static boolean optimizedIsHalloween() {
        return ((IsHalloweenInterface) Potatoptimize.almightyServerInstance).isNearHalloween();
    }
}
