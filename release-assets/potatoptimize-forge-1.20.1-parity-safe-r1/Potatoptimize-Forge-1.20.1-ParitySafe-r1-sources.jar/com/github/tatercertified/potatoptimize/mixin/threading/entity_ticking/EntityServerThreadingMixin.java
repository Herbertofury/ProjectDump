package com.github.tatercertified.potatoptimize.mixin.threading.entity_ticking;

import com.github.tatercertified.potatoptimize.utils.interfaces.ServerEntityThreadInterface;
import com.github.tatercertified.potatoptimize.utils.threading.ThreadedTaskExecutor;
import com.mojang.datafixers.DataFixer;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.Services;
import net.minecraft.server.TickTask;
import net.minecraft.server.WorldStem;
import net.minecraft.server.level.progress.ChunkProgressListenerFactory;
import net.minecraft.server.packs.repository.PackRepository;
import net.minecraft.util.thread.ReentrantBlockableEventLoop;
import net.minecraft.world.level.storage.LevelStorageSource;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.net.Proxy;

@Mixin(MinecraftServer.class)
public abstract class EntityServerThreadingMixin extends ReentrantBlockableEventLoop<TickTask> implements ServerEntityThreadInterface {

    @Unique
    private ThreadedTaskExecutor executor;

    public EntityServerThreadingMixin(final String string) {
        super(string);
    }

    @Inject(method = "<init>", at = @At("TAIL"))
    private void createThreads(Thread serverThread, LevelStorageSource.LevelStorageAccess session, PackRepository dataPackManager, WorldStem saveLoader, Proxy proxy, DataFixer dataFixer, Services apiServices, ChunkProgressListenerFactory worldGenerationProgressListenerFactory, CallbackInfo ci) {
        this.executor = new ThreadedTaskExecutor(this, 4);
    }

    @Override
    public ThreadedTaskExecutor getEntityExecutor() {
        return this.executor;
    }
}
