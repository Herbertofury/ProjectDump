package com.github.tatercertified.potatoptimize.mixin.entity.statistics;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(Player.class)
public abstract class PlayerEntityStatsMixin extends LivingEntity {

    @Shadow public abstract void increaseStat(ResourceLocation stat, int amount);

    protected PlayerEntityStatsMixin(EntityType<? extends LivingEntity> entityType, Level world) {
        super(entityType, world);
    }

    @Unique
    private int count;

    @Redirect(method = "tick", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/player/PlayerEntity;incrementStat(Lnet/minecraft/util/Identifier;)V"))
    private void slowIncrementStat(Player instance, ResourceLocation stat) {
        count++;
        if (count == 19) {
            increaseStat(stat, 20);
            count = 0;
        }
    }
}
