package com.github.tatercertified.potatoptimize.mixin.random.world;

import com.github.tatercertified.potatoptimize.utils.random.ThreadLocalRandomImpl;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(Level.class)
public class RandomWorldMixin {
    @Shadow @Final @Mutable @Deprecated private RandomSource threadSafeRandom = new ThreadLocalRandomImpl();
    @Shadow @Final @Mutable public RandomSource random = new ThreadLocalRandomImpl();
    @Shadow @Mutable protected int lcgBlockSeed = random.m_188502_();
}
