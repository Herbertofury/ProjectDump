package com.github.tatercertified.potatoptimize.mixin.logic.fast_rotations;

import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.core.Rotations;
import net.minecraft.nbt.FloatTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.util.Mth;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/**
 * Credit to PaperMC patch #0565
 */
//TODO Rewrite this so that pitch, yaw, and roll can be inlined properly
@Mixin(Rotations.class)
public class EulerAngleMixin {

    @Mutable
    @Unique
    @Final
    private static float pitch;
    @Unique
    @Final
    @Mutable
    private static float yaw;
    @Unique
    @Final
    @Mutable
    private static float roll;

    @Redirect(method = "<init>(FFF)V", at = @At(value = "FIELD", target = "Lnet/minecraft/util/math/EulerAngle;pitch:F"))
    private void injectedPitch(Rotations instance, float value, @Local(ordinal = 0) float pitch) {
        EulerAngleMixin.pitch = pitch;
    }

    @Redirect(method = "<init>(FFF)V", at = @At(value = "FIELD", target = "Lnet/minecraft/util/math/EulerAngle;yaw:F"))
    private void injectedYaw(Rotations instance, float value, @Local(ordinal = 0) float yaw) {
        EulerAngleMixin.yaw = yaw;
    }

    @Redirect(method = "<init>(FFF)V", at = @At(value = "FIELD", target = "Lnet/minecraft/util/math/EulerAngle;roll:F"))
    private void injectedRoll(Rotations instance, float value, @Local(ordinal = 0) float roll) {
        EulerAngleMixin.roll = roll;
    }

    /**
     * @author QPCrummer
     * @reason make fast
     */
    @Overwrite
    public float getPitch() {
        return pitch;
    }

    /**
     * @author QPCrummer
     * @reason make fast
     */
    @Overwrite
    public float getYaw() {
        return yaw;
    }

    /**
     * @author QPCrummer
     * @reason make fast
     */
    @Overwrite
    public float getRoll() {
        return roll;
    }

    /**
     * @author QPCrummer
     * @reason make fast
     */
    @Overwrite
    public float getWrappedPitch() {
        return Mth.m_14177_(pitch);
    }

    /**
     * @author QPCrummer
     * @reason make fast
     */
    @Overwrite
    public float getWrappedYaw() {
        return Mth.m_14177_(yaw);
    }

    /**
     * @author QPCrummer
     * @reason make fast
     */
    @Overwrite
    public float getWrappedRoll() {
        return Mth.m_14177_(roll);
    }

    /**
     * @author QPCrummer
     * @reason make fast
     */
    @Overwrite
    public boolean equals(Object o) {
        if (!(o instanceof Rotations eulerAngle)) {
            return false;
        } else {
            return pitch == eulerAngle.m_123156_() && yaw == eulerAngle.m_123157_() && roll == eulerAngle.m_123158_();
        }
    }

    /**
     * @author QPCrummer
     * @reason make fast
     */
    @Overwrite
    public ListTag toNbt() {
        ListTag nbtList = new ListTag();
        nbtList.add(FloatTag.m_128566_(pitch));
        nbtList.add(FloatTag.m_128566_(yaw));
        nbtList.add(FloatTag.m_128566_(roll));
        return nbtList;
    }
}
