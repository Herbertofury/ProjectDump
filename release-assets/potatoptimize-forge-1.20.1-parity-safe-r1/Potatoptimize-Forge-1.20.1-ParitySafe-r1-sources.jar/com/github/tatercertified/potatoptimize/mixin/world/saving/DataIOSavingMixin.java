package com.github.tatercertified.potatoptimize.mixin.world.saving;

import com.github.tatercertified.potatoptimize.mixin.logic.main_thread.ExceptionHandlerInvoker;
import com.github.tatercertified.potatoptimize.utils.interfaces.AsyncChunkSaveInterface;
import net.minecraft.Util;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtIo;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.world.level.saveddata.SavedData;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;

import java.io.File;
import java.io.IOException;

// Credit to Paper PR #9408
@Mixin(SavedData.class)
public abstract class DataIOSavingMixin implements AsyncChunkSaveInterface {

    @Shadow public abstract CompoundTag writeNbt(CompoundTag nbt);

    @Shadow public abstract boolean isDirty();

    @Shadow public abstract void setDirty(boolean dirty);

    /**
     * @author QPCrummer
     * @reason Make async
     */
    @Overwrite
    public void save(File file) {
        save(file, false);
    }

    @Override
    public void save(File file, boolean async) {
        if (this.isDirty()) {
            CompoundTag compoundTag = new CompoundTag();
            compoundTag.m_128365_("data", this.writeNbt(new CompoundTag()));
            NbtUtils.m_264171_(compoundTag);

            Runnable writeRunnable = () -> {
                try {
                    NbtIo.m_128944_(compoundTag, file);
                } catch (IOException var4) {
                    ExceptionHandlerInvoker.getLogger().error("Could not save data {}", this, var4);
                }
            };

            if (async) {
                Util.m_183992_().execute(writeRunnable);
            } else {
                writeRunnable.run();
            }

            this.setDirty(false);
        }
    }
}
