package com.github.tatercertified.potatoptimize.mixin.logic.json;

import net.minecraft.server.dedicated.DedicatedPlayerList;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(DedicatedPlayerList.class)
public class PlayerListMixin {
    @Redirect(method = {"addToOperators", "removeFromOperators"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/server/dedicated/DedicatedPlayerManager;saveOpList()V"))
    private void removeExtraSave(DedicatedPlayerList instance) {
    }
}
