package com.github.tatercertified.potatoptimize.mixin.threading.client_tick;

import com.github.tatercertified.potatoptimize.Potatoptimize;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

import java.util.function.BooleanSupplier;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.multiplayer.chat.ChatListener;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.client.sounds.MusicManager;
import net.minecraft.client.sounds.SoundManager;
import net.minecraft.client.tutorial.Tutorial;
import net.minecraft.network.Connection;

@Mixin(Minecraft.class)
public abstract class ClientTickMixin {

    @Redirect(method = "tick", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/network/message/MessageHandler;processDelayedMessages()V"))
    private void redirectProcessDelayedMessages(ChatListener instance) {
        Potatoptimize.clientTickExecutor.submit(instance::m_240688_);
    }

    @Redirect(method = "tick", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/sound/MusicTracker;tick()V"))
    private void redirectMusicTracker(MusicManager instance) {
        Potatoptimize.clientTickExecutor.submit(instance::m_120183_);
    }

    @Redirect(method = "tick", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/sound/SoundManager;tick(Z)V"))
    private void redirectSoundManager(SoundManager instance, boolean paused) {
        Potatoptimize.clientTickExecutor.submit(() -> instance.m_120389_(paused));
    }

    @Redirect(method = "tick", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/tutorial/TutorialManager;tick()V"))
    private void redirectTutorialManager(Tutorial instance) {
        Potatoptimize.clientTickExecutor.submit(() -> instance.m_120596_());
    }

    @Redirect(method = "tick", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/world/ClientWorld;tick(Ljava/util/function/BooleanSupplier;)V"))
    private void redirectTickWorld(ClientLevel instance, BooleanSupplier shouldKeepTicking) {
        Potatoptimize.clientTickExecutor.submit(() -> instance.m_104726_(shouldKeepTicking));
    }

    @Redirect(method = "tick", at = @At(value = "INVOKE", target = "Lnet/minecraft/network/ClientConnection;tick()V"))
    private void redirectClientConnection(Connection instance) {
        Potatoptimize.clientTickExecutor.submit(instance::m_129483_);
    }

    @Redirect(method = "tick", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/texture/TextureManager;tick()V"))
    private void redirectTextureManager(TextureManager instance) {
        Potatoptimize.clientTickExecutor.submit(instance::m_7673_);
    }
}
