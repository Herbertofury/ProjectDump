package com.github.tatercertified.potatoptimize.mixin.block_entity.sign_ticking;

import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.entity.SignBlockEntity;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Credit to PaperMC for the original optimization
 * Patch 0974 from PaperMC
 */
@Mixin(SignBlockEntity.class)
public abstract class SignBlockEntityMixin extends BlockEntity {
    @Shadow @Nullable private UUID editor;

    @Shadow protected abstract void tryClearInvalidEditor(SignBlockEntity blockEntity, Level world, UUID uuid);

    public SignBlockEntityMixin(BlockEntityType<?> type, BlockPos pos, BlockState state) {
        super(type, pos, state);
    }

    @Inject(method = "getEditor", at = @At("HEAD"))
    private void checkEditor(CallbackInfoReturnable<UUID> cir) {
        if (this.m_58898_() && this.editor != null) {
            this.tryClearInvalidEditor((SignBlockEntity)(Object)this, this.m_58904_(), this.editor);
        }
    }
}
