package com.github.tatercertified.potatoptimize.mixin.entity.ticking;

import net.minecraft.world.damagesource.CombatTracker;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(LivingEntity.class)
abstract class LivingEntityMixin extends Entity {
    public LivingEntityMixin(EntityType<?> type, Level world) {
        super(type, world);
    }

    @Shadow protected abstract void sendEquipmentChanges();

    @Shadow public abstract CombatTracker getDamageTracker();

    @Shadow public abstract boolean isSleeping();

    @Shadow protected abstract boolean isSleepingInBed();

    @Shadow public abstract void wakeUp();

        @Redirect(method = "tick", at = @At(value = "FIELD", target = "Lnet/minecraft/world/World;isClient:Z"))
    private boolean redirectGetClient(Level instance) {
        if (this.m_142389_()) {
            this.sendEquipmentChanges();
            if (this.f_19797_ % 20 == 0) {
                this.getDamageTracker().m_19296_();
            }

            if (this.isSleeping() && !this.isSleepingInBed()) {
                this.wakeUp();
            }
        }
        return this.m_142389_();
    }
}
