package com.github.tatercertified.potatoptimize.mixin.world.biome_access;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.util.LinearCongruentialGenerator;
import net.minecraft.util.Mth;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.BiomeManager;
import org.spongepowered.asm.mixin.*;

/**
 * Credit to FXMorin (Unmerged PR for Lithium)
 */
@Mixin(BiomeManager.class)
public class BiomeAccessMixin {
    @Shadow
    @Final
    private BiomeManager.NoiseBiomeSource storage;

    @Shadow
    @Final
    private long seed;

    @Shadow
    private static double method_38108(long l) {return 0;}

    @Unique
    private static final double maxOffset = 0.4500000001D;

    /**
     * @author FX - PR0CESS
     * @reason I wanted to make it faster
     */
    @Overwrite
    public Holder<Biome> getBiome(BlockPos pos) {
        int xMinus2 = pos.m_123341_() - 2;
        int yMinus2 = pos.m_123342_() - 2;
        int zMinus2 = pos.m_123343_() - 2;
        int x = xMinus2 >> 2;
        int y = yMinus2 >> 2;
        int z = zMinus2 >> 2;
        double quartX = (double)(xMinus2 & 3) / 4.0D;
        double quartY = (double)(yMinus2 & 3) / 4.0D;
        double quartZ = (double)(zMinus2 & 3) / 4.0D;
        int smallestX = 0;
        double smallestDist = Double.POSITIVE_INFINITY;
        for(int biomeX = 0; biomeX < 8; ++biomeX) {
            boolean everyOtherQuad = (biomeX & 4) == 0;
            boolean everyOtherPair = (biomeX & 2) == 0;
            boolean everyOther =     (biomeX & 1) == 0;
            double quartXX = everyOtherQuad ? quartX : quartX - 1.0D;
            double quartYY = everyOtherPair ? quartY : quartY - 1.0D;
            double quartZZ = everyOther     ? quartZ : quartZ - 1.0D;

            double maxQuartYY = 0.0D,maxQuartZZ = 0.0D;
            if (biomeX != 0) {
                maxQuartYY = Mth.m_144952_(Math.max(quartYY + maxOffset, Math.abs(quartYY - maxOffset)));
                maxQuartZZ = Mth.m_144952_(Math.max(quartZZ + maxOffset, Math.abs(quartZZ - maxOffset)));
                double maxQuartXX = Mth.m_144952_(Math.max(quartXX + maxOffset, Math.abs(quartXX - maxOffset)));
                if (smallestDist < maxQuartXX + maxQuartYY + maxQuartZZ) {
                    continue;
                }
            }

            int xx = everyOtherQuad ? x : x + 1;
            int yy = everyOtherPair ? y : y + 1;
            int zz = everyOther ? z : z + 1;

            long seed = LinearCongruentialGenerator.m_13972_(this.seed, xx);
            seed = LinearCongruentialGenerator.m_13972_(seed, yy);
            seed = LinearCongruentialGenerator.m_13972_(seed, zz);
            seed = LinearCongruentialGenerator.m_13972_(seed, xx);
            seed = LinearCongruentialGenerator.m_13972_(seed, yy);
            seed = LinearCongruentialGenerator.m_13972_(seed, zz);
            double offsetX = method_38108(seed);
            double sqrX = Mth.m_144952_(quartXX + offsetX);
            if (biomeX != 0 && smallestDist < sqrX + maxQuartYY + maxQuartZZ) {
                continue;
            }
            seed = LinearCongruentialGenerator.m_13972_(seed, this.seed);
            double offsetY = method_38108(seed);
            double sqrY = Mth.m_144952_(quartYY + offsetY);
            if (biomeX != 0 && smallestDist < sqrX + sqrY + maxQuartZZ) {
                continue;
            }
            seed = LinearCongruentialGenerator.m_13972_(seed, this.seed);
            double offsetZ = method_38108(seed);
            double biomeDist = sqrX + sqrY + Mth.m_144952_(quartZZ + offsetZ);

            if (smallestDist > biomeDist) {
                smallestX = biomeX;
                smallestDist = biomeDist;
            }
        }

        int biomeX = (smallestX & 4) == 0 ? x : x + 1;
        int biomeY = (smallestX & 2) == 0 ? y : y + 1;
        int biomeZ = (smallestX & 1) == 0 ? z : z + 1;
        return this.storage.m_203495_(biomeX, biomeY, biomeZ);
    }
}
