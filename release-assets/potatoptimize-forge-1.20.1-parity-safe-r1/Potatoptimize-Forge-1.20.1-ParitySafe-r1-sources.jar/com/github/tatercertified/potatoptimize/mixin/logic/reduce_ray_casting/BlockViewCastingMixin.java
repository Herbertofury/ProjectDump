package com.github.tatercertified.potatoptimize.mixin.logic.reduce_ray_casting;

import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;

import java.util.function.BiFunction;
import java.util.function.Function;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.LevelHeightAccessor;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * Credit to PaperMC Patch #0687 and #684
 */

@Mixin(BlockGetter.class)
public interface BlockViewCastingMixin extends LevelHeightAccessor {
    @Shadow BlockState getBlockState(BlockPos pos);

    @Shadow @Nullable BlockHitResult raycastBlock(Vec3 start, Vec3 end, BlockPos pos, VoxelShape shape, BlockState state);

    @Shadow static <T, C> T raycast(Vec3 start, Vec3 end, C context, BiFunction<C, BlockPos, T> blockHitFactory, Function<C, T> missFactory){return null;}

    /**
     * @author QPCrummer
     * @reason Optimize
     */
    @Overwrite
    default BlockHitResult raycast(ClipContext context) {
        return raycast(context.m_45702_(), context.m_45693_(), context, (innerContext, pos) -> {
            BlockState blockState = this.getBlockState(pos);
            if (blockState.m_60795_()) return null;
            FluidState fluidState = blockState.m_60819_();
            Vec3 vec3d = innerContext.m_45702_();
            Vec3 vec3d2 = innerContext.m_45693_();
            VoxelShape voxelShape = innerContext.m_45694_(blockState, (BlockGetter)(Object)this, pos);
            BlockHitResult blockHitResult = this.raycastBlock(vec3d, vec3d2, pos, voxelShape, blockState);
            VoxelShape voxelShape2 = innerContext.m_45698_(fluidState, (BlockGetter)(Object)this, pos);
            BlockHitResult blockHitResult2 = voxelShape2.m_83220_(vec3d, vec3d2, pos);
            double d = blockHitResult == null ? Double.MAX_VALUE : innerContext.m_45702_().m_82557_(blockHitResult.m_82450_());
            double e = blockHitResult2 == null ? Double.MAX_VALUE : innerContext.m_45702_().m_82557_(blockHitResult2.m_82450_());
            return d <= e ? blockHitResult : blockHitResult2;
        }, (innerContext) -> {
            Vec3 vec3d = innerContext.m_45702_().m_82546_(innerContext.m_45693_());
            return BlockHitResult.m_82426_(innerContext.m_45693_(), Direction.m_122366_(vec3d.f_82479_, vec3d.f_82480_, vec3d.f_82481_), BlockPos.m_274446_(innerContext.m_45693_()));
        });
    }
}
