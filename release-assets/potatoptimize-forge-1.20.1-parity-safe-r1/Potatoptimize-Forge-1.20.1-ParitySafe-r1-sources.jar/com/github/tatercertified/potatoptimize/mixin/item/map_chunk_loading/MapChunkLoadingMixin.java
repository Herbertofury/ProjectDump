package com.github.tatercertified.potatoptimize.mixin.item.map_chunk_loading;

import com.github.tatercertified.potatoptimize.utils.interfaces.ChunkQuery;
import net.minecraft.core.SectionPos;
import net.minecraft.world.item.MapItem;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.chunk.LevelChunk;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(MapItem.class)
public class MapChunkLoadingMixin {

    @Redirect(method = "updateColors", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/World;getChunk(II)Lnet/minecraft/world/chunk/WorldChunk;"))
    private LevelChunk lazyUpdateColors(Level instance, int i, int j) {
        return ((ChunkQuery)(instance)).getChunkIfLoaded(SectionPos.m_123171_(i), SectionPos.m_123171_(j));
    }

    @Redirect(method = "updateColors", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/chunk/WorldChunk;isEmpty()Z"))
    private boolean additionalContext(LevelChunk instance) {
        return instance != null && !instance.m_6430_();
    }

}
