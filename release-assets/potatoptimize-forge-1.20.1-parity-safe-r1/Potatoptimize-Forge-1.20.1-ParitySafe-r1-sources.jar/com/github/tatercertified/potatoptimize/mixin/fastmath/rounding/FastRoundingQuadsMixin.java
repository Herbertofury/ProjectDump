package com.github.tatercertified.potatoptimize.mixin.fastmath.rounding;

import com.github.tatercertified.potatoptimize.utils.math.FasterMathUtil;
import net.minecraft.client.renderer.block.model.FaceBakery;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(FaceBakery.class)
public class FastRoundingQuadsMixin {
    @Redirect(
            method = "uvLock(Lnet/minecraft/client/render/model/json/ModelElementTexture;Lnet/minecraft/util/math/"+
                    "Direction;Lnet/minecraft/util/math/AffineTransformation;Lnet/minecraft/util/Identifier;)"+
                    "Lnet/minecraft/client/render/model/json/ModelElementTexture;",
            require = 0,
            at = @At(value = "INVOKE", target = "Ljava/lang/Math;round(D)J"))
    private static long fasterRound(double value) {
        return FasterMathUtil.round(value);
    }
}
