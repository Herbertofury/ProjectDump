package com.github.tatercertified.potatoptimize.mixin.unstream.tacs;

import org.spongepowered.asm.mixin.*;

import java.util.List;
import net.minecraft.server.level.ChunkMap;
import net.minecraft.world.entity.Entity;

@Mixin(ChunkMap.TrackedEntity.class)
public abstract class ThreadedAnvilUnstreamMixin {
    @Shadow protected abstract int adjustTrackingDistance(int initialDistance);

    @Shadow @Final Entity entity;

    @Shadow @Final private int maxDistance;

    @Unique
    private int getHighestRange(Entity parent, int highest) {
        List<Entity> passengers = parent.m_20197_();

        for (Entity entity : passengers) {
            int range = entity.m_6095_().m_20681_() * 16;

            if (range > highest) {
                highest = range;
            }

            highest = getHighestRange(entity, highest);
        }

        return highest;
    }

    /**
     * @author QPCrummer
     * @reason Remove Stream API
     */
    @Overwrite
    private int getMaxTrackDistance() {
        return this.adjustTrackingDistance(this.getHighestRange(this.entity, this.maxDistance));
    }
}
