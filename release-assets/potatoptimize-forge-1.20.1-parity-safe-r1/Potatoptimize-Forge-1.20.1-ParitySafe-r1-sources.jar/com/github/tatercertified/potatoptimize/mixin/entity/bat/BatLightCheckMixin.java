package com.github.tatercertified.potatoptimize.mixin.entity.bat;

import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.core.BlockPos;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.ambient.Bat;
import net.minecraft.world.level.LevelAccessor;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Bat.class)
public class BatLightCheckMixin {
    @Redirect(method = "canSpawn", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/WorldAccess;getLightLevel(Lnet/minecraft/util/math/BlockPos;)I"))
    private static int removeLightCheck(LevelAccessor instance, BlockPos blockPos) {
        return 0;
    }

    @Inject(method = "canSpawn", at = @At(value = "INVOKE", target = "Lnet/minecraft/util/math/random/Random;nextInt(I)I"), cancellable = true)
    private static void readdLightCheck(EntityType<Bat> type, LevelAccessor world, MobSpawnType spawnReason, BlockPos pos, RandomSource random, CallbackInfoReturnable<Boolean> cir, @Local(ordinal = 1) int j) {
        if (world.m_46803_(pos) > random.m_188503_(j)) {
            cir.setReturnValue(false);
        }
        cir.setReturnValue(Bat.m_217057_(type, world, spawnReason, pos, random));
    }
}
