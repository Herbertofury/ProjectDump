package com.github.tatercertified.potatoptimize.mixin.entity.halloween;

import com.github.tatercertified.potatoptimize.utils.interfaces.IsHalloweenInterface;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(Zombie.class)
public abstract class ZombieEntityMixin extends Monster {

    protected ZombieEntityMixin(EntityType<? extends Monster> entityType, Level world) {
        super(entityType, world);
    }

    @Redirect(method = "initialize", at = @At(value = "INVOKE", target = "Lnet/minecraft/item/ItemStack;isEmpty()Z"))
    private boolean cancelHalloweenCheck(ItemStack instance) {
        if (((IsHalloweenInterface)this.m_20194_()).isHalloween() && f_19796_.m_188501_() < 0.25f) {
            this.m_8061_(EquipmentSlot.HEAD, new ItemStack(f_19796_.m_188501_() < 0.1f ? Blocks.f_50144_ : Blocks.f_50143_));
            this.f_21348_[EquipmentSlot.HEAD.m_20749_()] = 0.0f;
        }
        return false;
    }
}
