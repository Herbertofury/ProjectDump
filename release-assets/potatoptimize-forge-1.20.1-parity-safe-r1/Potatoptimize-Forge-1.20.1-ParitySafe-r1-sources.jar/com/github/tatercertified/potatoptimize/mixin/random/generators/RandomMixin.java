package com.github.tatercertified.potatoptimize.mixin.random.generators;

import com.github.tatercertified.potatoptimize.utils.random.ThreadLocalRandomImpl;
import io.netty.util.internal.ThreadLocalRandom;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.levelgen.RandomSupport;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;

@Mixin(RandomSource.class)
public interface RandomMixin {
    /**
     * @author QPCrummer
     * @reason Use my implementation of ThreadLocalRandom
     */
    @Deprecated
    @Overwrite
    static RandomSource createThreadSafe() {
        return new ThreadLocalRandomImpl(RandomSupport.m_224599_());
    }

    /**
     * @author QPCrummer
     * @reason Use my implementation of ThreadLocalRandom
     */
    @Overwrite
    static RandomSource createLocal() {
        return new ThreadLocalRandomImpl(ThreadLocalRandom.current().nextLong());
    }

    /**
     * @author QPCrummer
     * @reason Use my implementation of ThreadLocalRandom
     *
     * This has been removed for now as it causes issues with chunk rebuilding!
     *
    @Overwrite
    static Random create(long seed) {
        return new ThreadLocalRandomImpl(seed);
    }
     */
}
