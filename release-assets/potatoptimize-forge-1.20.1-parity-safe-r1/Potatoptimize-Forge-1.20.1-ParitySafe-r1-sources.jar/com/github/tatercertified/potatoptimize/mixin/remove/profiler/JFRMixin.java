package com.github.tatercertified.potatoptimize.mixin.remove.profiler;

import net.minecraft.resources.ResourceKey;
import net.minecraft.util.profiling.jfr.Environment;
import net.minecraft.util.profiling.jfr.JfrProfiler;
import net.minecraft.util.profiling.jfr.callback.ProfiledDuration;
import net.minecraft.util.profiling.jfr.event.NetworkSummaryEvent;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;
import org.slf4j.LoggerFactory;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;

import java.io.Reader;
import java.net.SocketAddress;
import java.nio.file.Path;

@Mixin(JfrProfiler.class)
public class JFRMixin {

    /**
     * @author QPCrummer
     * @reason Removal
     */
    @Overwrite
    public boolean start(Environment instanceType) {
        LoggerFactory.getLogger("Potatoptimize").warn("/jfr has been removed; Use spark or alternative instead!");
        return false;
    }

    /**
     * @author QPCrummer
     * @reason Removal
     */
    @Overwrite
    public Path stop() {
        return null;
    }

    /**
     * @author QPCrummer
     * @reason Removal
     */
    @Overwrite
    public boolean isProfiling() {
        return false;
    }

    /**
     * @author QPCrummer
     * @reason Removal
     */
    @Overwrite
    public boolean isAvailable() {
        return false;
    }

    /**
     * @author QPCrummer
     * @reason Removal
     */
    @Overwrite
    private boolean start(Reader reader, Environment instanceType) {
        return false;
    }

    /**
     * @author QPCrummer
     * @reason Removal
     */
    @Overwrite
    private void addListener() {
    }

    /**
     * @author QPCrummer
     * @reason Removal
     */
    @Overwrite
    public void onTick(float tickTime) {
    }

    /**
     * @author QPCrummer
     * @reason Removal
     */
    @Overwrite
    public void onPacketReceived(int protocolId, int packetId, SocketAddress remoteAddress, int bytes) {
    }

    /**
     * @author QPCrummer
     * @reason Removal
     */
    @Overwrite
    public void onPacketSent(int protocolId, int packetId, SocketAddress remoteAddress, int bytes) {
    }

    /**
     * @author QPCrummer
     * @reason Removal
     */
    @Overwrite
    private NetworkSummaryEvent.SumAggregation getOrCreateSummaryRecorder(SocketAddress address) {
        return null;
    }

    /**
     * @author QPCrummer
     * @reason Removal
     */
    @Overwrite
    public @Nullable ProfiledDuration startWorldLoadProfiling() {
        return null;
    }

    /**
     * @author QPCrummer
     * @reason Removal
     */
    @Overwrite
    public @Nullable ProfiledDuration startChunkGenerationProfiling(ChunkPos chunkPos, ResourceKey<Level> world, String targetStatus) {
        return null;
    }
}
