package com.github.tatercertified.potatoptimize.mixin.unstream.nearest_item;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;

import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.Brain;
import net.minecraft.world.entity.ai.memory.MemoryModuleType;
import net.minecraft.world.entity.ai.sensing.NearestItemSensor;
import net.minecraft.world.entity.item.ItemEntity;

@Mixin(NearestItemSensor.class)
public class NearestItemSensorMixin {

    /**
     * @author QPCrummer
     * @reason Remove Streams
     */
    @Overwrite
    public void sense(ServerLevel serverWorld, Mob mobEntity) {
        Brain<?> brain = mobEntity.m_6274_();
        List<ItemEntity> list = serverWorld.m_6443_(ItemEntity.class, mobEntity.m_20191_().m_82377_(32.0, 16.0, 32.0), (itemEntity) -> true);
        Objects.requireNonNull(mobEntity);
        list.sort(Comparator.comparingDouble(mobEntity::m_20280_));
        ItemEntity nearest = null;
        for (ItemEntity item : list) {
            if (mobEntity.m_7252_(item.m_32055_()) && item.m_19950_(mobEntity, 32.0D) && mobEntity.m_142582_(item)) {
                nearest = item;
                break;
            }
        }
        brain.m_21886_(MemoryModuleType.f_26332_, Optional.ofNullable(nearest));
    }
}
