package com.github.tatercertified.potatoptimize.mixin.networking.block_breaking;

import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.core.BlockPos;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientboundBlockDestructionPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

// Credit Mirai patch #0061
@Mixin(ServerLevel.class)
public class CacheBlockBreakPacketMixin {
    @Unique
    private ClientboundBlockDestructionPacket packet;

    @Inject(method = "setBlockBreakingInfo", at = @At("HEAD"))
    private void setPacketNull(int entityId, BlockPos pos, int progress, CallbackInfo ci) {
        this.packet = null;
    }

    @Redirect(method = "setBlockBreakingInfo", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/network/ServerPlayNetworkHandler;sendPacket(Lnet/minecraft/network/packet/Packet;)V"))
    private void redirectPacketSent(ServerGamePacketListenerImpl instance, Packet<?> packetBad, @Local(ordinal = 0) int entityId, @Local(ordinal = 0) BlockPos pos, @Local(ordinal = 0) int progress, @Local(ordinal = 0)ServerPlayer serverPlayerEntity) {
        if (this.packet == null) this.packet = new ClientboundBlockDestructionPacket(entityId, pos, progress);
        serverPlayerEntity.f_8906_.m_9829_(this.packet);
    }
}
