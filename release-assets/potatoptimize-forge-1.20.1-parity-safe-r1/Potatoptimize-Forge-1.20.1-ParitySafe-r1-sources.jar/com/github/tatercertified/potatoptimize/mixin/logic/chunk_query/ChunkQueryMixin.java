package com.github.tatercertified.potatoptimize.mixin.logic.chunk_query;

import com.github.tatercertified.potatoptimize.utils.interfaces.ChunkQuery;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.chunk.LevelChunk;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(Level.class)
public abstract class ChunkQueryMixin implements ChunkQuery, LevelAccessor, AutoCloseable {

    @Override
    public LevelChunk getChunkIfLoaded(int x, int y) {
        return this.m_7232_(x, y) ? (LevelChunk) this.m_6325_(x, y) : null;
    }

    @Override
    public LevelChunk getChunkIfLoaded(BlockPos pos) {
        return this.m_7232_(pos.m_123341_(), pos.m_123343_()) ? (LevelChunk) this.m_46865_(pos) : null;
    }

    @Override
    public boolean isChunkNearby(BlockPos pos1, BlockPos pos2, int limit) {
        return pos1.m_123314_(pos2, limit);
    }

    @Override
    public LevelChunk getChunkIfNearAndLoaded(BlockPos entityPos, BlockPos chunkPos, int limit) {
        return this.isChunkNearby(entityPos, chunkPos, limit) ? this.getChunkIfLoaded(chunkPos) : null;
    }
}
