package com.github.tatercertified.potatoptimize.mixin.remove.profiler;

import org.apache.commons.lang3.tuple.Pair;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;

import java.util.Set;
import java.util.function.Supplier;
import net.minecraft.util.profiling.ActiveProfiler;
import net.minecraft.util.profiling.ProfileResults;
import net.minecraft.util.profiling.metrics.MetricCategory;

@Mixin(ActiveProfiler.class)
public class ProfilerSystemMixin {

    /**
     * @author QPCrummer
     * @reason Removal
     */
    @Overwrite
    public void startTick() {
    }

    /**
     * @author QPCrummer
     * @reason Removal
     */
    @Overwrite
    public void endTick() {
    }

    /**
     * @author QPCrummer
     * @reason Removal
     */
    @Overwrite
    public void push(String location) {
    }

    /**
     * @author QPCrummer
     * @reason Removal
     */
    @Overwrite
    public void push(Supplier<String> locationGetter) {
    }

    /**
     * @author QPCrummer
     * @reason Removal
     */
    @Overwrite
    public void markSampleType(MetricCategory type) {
    }

    /**
     * @author QPCrummer
     * @reason Removal
     */
    @Overwrite
    public void pop() {
    }

    /**
     * @author QPCrummer
     * @reason Removal
     */
    @Overwrite
    public void swap(String location) {
    }

    /**
     * @author QPCrummer
     * @reason Removal
     */
    @Overwrite
    public void swap(Supplier<String> locationGetter) {
    }

    /**
     * @author QPCrummer
     * @reason Removal
     */
    @Overwrite
    private ActiveProfiler.PathEntry getCurrentInfo() {
        return null;
    }

    /**
     * @author QPCrummer
     * @reason Removal
     */
    @Overwrite
    public void visit(String marker, int num) {
    }

    /**
     * @author QPCrummer
     * @reason Removal
     */
    @Overwrite
    public void visit(Supplier<String> markerGetter, int num) {
    }

    /**
     * @author QPCrummer
     * @reason Removal
     */
    @Overwrite
    public ProfileResults getResult() {
        return null;
    }

    /**
     * @author QPCrummer
     * @reason Removal
     */
    @Overwrite
    public ActiveProfiler.@Nullable PathEntry getInfo(String name) {
        return null;
    }

    /**
     * @author QPCrummer
     * @reason Removal
     */
    @Overwrite
    public Set<Pair<String, MetricCategory>> getSampleTargets() {
        return null;
    }

}
