package com.github.tatercertified.potatoptimize.mixin.entity.teleport;

import com.github.tatercertified.potatoptimize.utils.interfaces.SmoothTeleportInterface;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.network.protocol.Packet;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import net.minecraft.server.players.PlayerList;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(PlayerList.class)
public class SmoothTeleportPlayerManagerMixin {
    @Redirect(method = "respawnPlayer", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/network/ServerPlayNetworkHandler;sendPacket(Lnet/minecraft/network/packet/Packet;)V", ordinal = 0))
    private void removeSendPacket(ServerGamePacketListenerImpl instance, Packet packet, @Local(ordinal = 0) ServerPlayer serverPlayerEntity) {
        if (!((SmoothTeleportInterface)serverPlayerEntity).shouldSmoothTeleport()) {
            instance.m_9829_(packet);
        }
    }

    @Redirect(method = "respawnPlayer", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/network/ServerPlayNetworkHandler;requestTeleport(DDDFF)V"))
    private void removeSpawnRequest(ServerGamePacketListenerImpl instance, double x, double y, double z, float yaw, float pitch, @Local(ordinal = 0) ServerPlayer serverPlayerEntity) {
        if (!((SmoothTeleportInterface)serverPlayerEntity).shouldSmoothTeleport()) {
            instance.m_9774_(x, y, z, yaw, pitch);
        }
    }
}
