package com.github.tatercertified.potatoptimize.mixin.remove.profiler;

import net.minecraft.commands.CommandSourceStack;
import net.minecraft.network.chat.Component;
import net.minecraft.server.commands.JfrCommand;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;

@Mixin(JfrCommand.class)
public class JFRCommandMixin {
    /**
     * @author QPCrummer
     * @reason Removal
     */
    @Overwrite
    private static int executeStart(CommandSourceStack source) {
        source.m_288197_(() -> Component.m_237113_("JFR has been removed by Potatoptimize; Use Spark instead!"), false);
        return 0;
    }

    /**
     * @author QPCrummer
     * @reason Removal
     */
    @Overwrite
    private static int executeStop(CommandSourceStack source) {
        source.m_288197_(() -> Component.m_237113_("JFR has been removed by Potatoptimize; Use Spark instead!"), false);
        return 0;
    }
}
