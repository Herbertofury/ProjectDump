package com.github.tatercertified.potatoptimize.utils.random;

import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.levelgen.PositionalRandomFactory;

public class ThreadLocalRandomImpl implements PotatoptimizedRandom {
    private final ThreadLocalRandom random = ThreadLocalRandom.current();

    public static final RandomSource INSTANCE = new ThreadLocalRandomImpl();
    public ThreadLocalRandomImpl() {
    }

    public ThreadLocalRandomImpl(long ignoredSeed) {
    }

    @Override
    public RandomSource m_213769_() {
        return this;
    }

    @Override
    public PositionalRandomFactory m_188582_() {
        return new Splitter(0L,this);
    }

    @Override
    public void m_188584_(long seed) {
    }

    @Override
    public int m_188502_() {
        return this.random.nextInt();
    }

    @Override
    public int m_188503_(int bound) {
        return this.random.nextInt(bound);
    }

    @Override
    public int m_216332_(int min, int max) {
        if (min >= max) {
            return min;
        }
        return this.random.nextInt(min, max);
    }

    @Override
    public long m_188505_() {
        return this.random.nextLong();
    }

    @Override
    public boolean m_188499_() {
        return this.random.nextBoolean();
    }

    @Override
    public float m_188501_() {
        return this.random.nextFloat();
    }

    @Override
    public double m_188500_() {
        return this.random.nextDouble();
    }

    @Override
    public double m_188583_() {
        return quickGaussian();
    }


    // Gaussian Code
    private double quickGaussian() {
        long randomBits = m_188505_();
        long evenChunks = randomBits & EVEN_CHUNKS;
        long oddChunks = (randomBits & ODD_CHUNKS) >>> 5;
        long sum = chunkSum(evenChunks + oddChunks) - 186;
        return sum / 31.0;
    }

    private long chunkSum(long bits) {
        long sum = bits + (bits >>> 40);
        sum += sum >>> 20;
        sum += sum >>> 10;
        sum &= (1<<10)-1;
        return sum;
    }

    private final long EVEN_CHUNKS = 0x7c1f07c1f07c1fL;
    private final long ODD_CHUNKS  = EVEN_CHUNKS << 5;

    @Override
    public double nextDouble(double bound) {
        return this.random.nextDouble(bound);
    }

    @Override
    public double nextDouble(double min, double max) {
        if (min >= max) {
            return min;
        }
        return this.random.nextDouble(min, max);
    }

    @Override
    public float nextFloat(float bound) {
        return this.random.nextFloat(bound);
    }

    @Override
    public float nextFloat(float min, float max) {
        if (min >= max) {
            return min;
        }
        return this.random.nextFloat(min, max);
    }

    @Override
    public float nextGaussian(float mean, float deviation) {
        return (float) (mean + quickGaussian() * deviation);
    }

    @Override
    public UUID nextUUID() {
        return new UUID( m_188505_() & 0xFFFFFFFFFFFF0FFFL | 0x4000L, m_188505_()  & 0x3FFFFFFFFFFFFFFFL | Long.MIN_VALUE);
    }

    public record Splitter(long seed, ThreadLocalRandomImpl instance) implements PositionalRandomFactory {
        @Override
        public RandomSource m_214111_(String seed) {
            int i = seed.hashCode();
            return new ThreadLocalRandomImpl((long)i ^ this.seed);
        }

        @Override
        public RandomSource m_213715_(int x, int y, int z) {
            long l = Mth.m_14130_(x, y, z);
            long m = l ^ this.seed;
            return new ThreadLocalRandomImpl(m);
        }

        @Override
        public void m_183502_(StringBuilder info) {
            info.append("seed: ").append(this.seed);
        }
    }
}
