package com.github.tatercertified.potatoptimize.utils.interfaces;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.chunk.LevelChunk;

public interface ChunkQuery {
    LevelChunk getChunkIfLoaded(int x, int y);
    LevelChunk getChunkIfLoaded(BlockPos pos);
    boolean isChunkNearby(BlockPos pos1, BlockPos pos2, int limit);
    LevelChunk getChunkIfNearAndLoaded(BlockPos pos1, BlockPos pos2, int limit);
}
