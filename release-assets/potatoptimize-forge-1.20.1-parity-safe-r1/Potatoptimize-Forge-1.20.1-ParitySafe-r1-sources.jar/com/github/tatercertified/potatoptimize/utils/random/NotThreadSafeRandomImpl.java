package com.github.tatercertified.potatoptimize.utils.random;

import java.util.UUID;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.levelgen.PositionalRandomFactory;

// TODO Finish this

/**
 * Credit to PaperMC patch #06911
 */
public class NotThreadSafeRandomImpl implements PotatoptimizedRandom {
    private final long multiplier = 0x5DEECE66DL;
    private final long addend = 0xBL;
    private final long mask = (1L << 48) - 1;
    private long seed;

    public static final RandomSource INSTANCE = new NotThreadSafeRandomImpl();

    public NotThreadSafeRandomImpl(long seed) {
        this.seed = seed;
    }

    public NotThreadSafeRandomImpl() {
        this.m_188584_(m_188505_());
    }

    @Override
    public double nextDouble(double bound) {
        return 0;
    }

    @Override
    public double nextDouble(double origin, double bound) {
        return 0;
    }

    @Override
    public float nextFloat(float bound) {
        return 0;
    }

    @Override
    public float nextFloat(float origin, float bound) {
        return 0;
    }

    @Override
    public float nextGaussian(float mean, float deviation) {
        return 0;
    }

    @Override
    public UUID nextUUID() {
        return null;
    }

    @Override
    public RandomSource m_213769_() {
        return null;
    }

    @Override
    public PositionalRandomFactory m_188582_() {
        return null;
    }

    @Override
    public void m_188584_(long seed) {
        this.seed = scrambleSeed(seed);
    }

    @Override
    public int m_188502_() {
        return 0;
    }

    @Override
    public int m_188503_(int bound) {
        return fastBoundedLong(this.next(32) & 0xFFFFFFFFL, bound);
    }

    @Override
    public long m_188505_() {
        return 0;
    }

    @Override
    public boolean m_188499_() {
        return false;
    }

    @Override
    public float m_188501_() {
        return 0;
    }

    @Override
    public double m_188500_() {
        return 0;
    }

    @Override
    public double m_188583_() {
        return 0;
    }

    private long scrambleSeed(long seed) {
        return (seed ^ multiplier) & mask;
    }

    private int fastBoundedLong(final long randomInteger, final long limit) {
        return (int)((randomInteger * limit) >>> 32);
    }

    private int next(int bits) {
        return (int) (((this.seed = this.seed * multiplier + addend) & mask) >>> (48 - bits));
    }
}
