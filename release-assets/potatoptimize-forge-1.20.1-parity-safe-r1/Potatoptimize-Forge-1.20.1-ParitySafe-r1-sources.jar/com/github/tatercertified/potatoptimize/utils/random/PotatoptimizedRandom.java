package com.github.tatercertified.potatoptimize.utils.random;

import java.util.UUID;
import net.minecraft.util.RandomSource;

public interface PotatoptimizedRandom extends RandomSource {
    double nextDouble(double bound);
    double nextDouble(double origin, double bound);
    float nextFloat(float bound);
    float nextFloat(float origin, float bound);
    float nextGaussian(float mean, float deviation);
    UUID nextUUID();
}
