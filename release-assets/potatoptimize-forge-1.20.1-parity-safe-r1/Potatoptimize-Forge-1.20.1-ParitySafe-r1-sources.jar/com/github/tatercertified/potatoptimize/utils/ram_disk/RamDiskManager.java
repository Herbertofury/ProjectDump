package com.github.tatercertified.potatoptimize.utils.ram_disk;

import java.io.File;
import net.minecraft.world.level.chunk.storage.RegionFile;

public interface RamDiskManager {
    void createRamDisk(int size, String mountPath);
    void removeRamDisk();
    void uploadFile(RegionFile file);
    void removeFile(RegionFile file);
    int getRamDiskSize();
    RegionFile[] getRamDiskFiles();
    void adjustRamDiskSize(int newSize);
}
