package com.github.tatercertified.potatoptimize.utils.interfaces;

import net.minecraft.server.level.ServerLevel;

public interface SmoothTeleportInterface {
    void setSmoothTeleport(boolean bool);
    boolean shouldSmoothTeleport();
    void smoothTeleport(ServerLevel targetWorld, double x, double y, double z, float yaw, float pitch);
}
