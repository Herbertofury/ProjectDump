import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.jar.*;
import jdk.internal.org.objectweb.asm.*;
import jdk.internal.org.objectweb.asm.tree.*;

public final class C2MEPerformanceSafePatcherV3Standalone implements Opcodes {
    private static final String ASYNC_LOCK = "com/ishland/c2me/base/common/util/AsyncCombinedLock.class";
    private static final String SCHED_LOCK = "com/ishland/c2me/base/common/scheduler/SchedulingAsyncCombinedLock.class";
    private static final String FLAG_MATRIX = "com/ishland/c2me/fixes/worldgen/threading_issues/common/ConcurrentFlagMatrix.class";
    private static final String SYNC_CODEC = "com/ishland/c2me/fixes/chunkio/threading_issues/common/SynchronizedCodec.class";
    private static final String SYNC_LOCKER = "com/ishland/c2me/fixes/chunkio/threading_issues/common/SynchronizedCodec$ManagedLocker.class";
    private static final String OLD_HELPER = "com/ishland/c2me/base/common/util/C2MELockOrder.class";
    private static final String OLD_MARKER = "META-INF/noxviola-c2me-safe-hardening.txt";
    private static final String MARKER = "META-INF/noxviola-c2me-performance-safe-v3.txt";


    static final class SafeClassWriter extends ClassWriter {
        SafeClassWriter(int flags) { super(flags); }
        @Override protected String getCommonSuperClass(String a, String b) {
            if (a.equals(b)) return a;
            if (a.startsWith("java/") && b.startsWith("java/")) {
                try {
                    Class<?> ca = Class.forName(a.replace('/','.'));
                    Class<?> cb = Class.forName(b.replace('/','.'));
                    if (ca.isAssignableFrom(cb)) return a;
                    if (cb.isAssignableFrom(ca)) return b;
                    if (ca.isInterface() || cb.isInterface()) return "java/lang/Object";
                    do { ca = ca.getSuperclass(); } while (ca != null && !ca.isAssignableFrom(cb));
                    if (ca != null) return ca.getName().replace('.','/');
                } catch (Throwable ignored) {}
            }
            return "java/lang/Object";
        }
    }

    static AbstractInsnNode prevReal(AbstractInsnNode n) {
        AbstractInsnNode p = n.getPrevious();
        while (p != null && (p.getType() == AbstractInsnNode.LABEL || p.getType() == AbstractInsnNode.LINE || p.getType() == AbstractInsnNode.FRAME)) p = p.getPrevious();
        return p;
    }

    static byte[] patchImpossibleRelockRecursion(byte[] in, String owner, String methodDesc) {
        ClassNode cn = new ClassNode();
        new ClassReader(in).accept(cn, 0);
        boolean patched = false;
        for (MethodNode m : cn.methods) {
            if (!m.name.equals("tryAcquire") || !m.desc.equals(methodDesc)) continue;
            for (AbstractInsnNode n = m.instructions.getFirst(); n != null; n = n.getNext()) {
                if (n instanceof LdcInsnNode ldc && "Some issue occurred while doing locking, retrying".equals(ldc.cst)) {
                    AbstractInsnNode start = prevReal(n);
                    if (!(start instanceof FieldInsnNode fi) || start.getOpcode() != GETSTATIC || !fi.owner.equals("java/lang/System") || !fi.name.equals("err")) {
                        throw new IllegalStateException("unexpected relock diagnostic shape in " + owner);
                    }
                    AbstractInsnNode end = n;
                    while (end != null) {
                        if (end instanceof MethodInsnNode mi && mi.owner.equals(owner) && mi.name.equals("tryAcquire") && mi.desc.equals(methodDesc)) break;
                        end = end.getNext();
                    }
                    if (end == null) throw new IllegalStateException("recursive tryAcquire call not found in " + owner);
                    AbstractInsnNode maybeReturn = end.getNext();
                    while (maybeReturn != null && (maybeReturn.getType() == AbstractInsnNode.LABEL || maybeReturn.getType() == AbstractInsnNode.LINE || maybeReturn.getType() == AbstractInsnNode.FRAME)) maybeReturn = maybeReturn.getNext();
                    if (methodDesc.equals("()Z") && maybeReturn != null && maybeReturn.getOpcode() == IRETURN) end = maybeReturn;
                    InsnList repl = new InsnList();
                    repl.add(new TypeInsnNode(NEW, "java/lang/IllegalStateException"));
                    repl.add(new InsnNode(DUP));
                    repl.add(new LdcInsnNode("Failed to acquire any lock during tryAcquire - logical lock-state error"));
                    repl.add(new MethodInsnNode(INVOKESPECIAL, "java/lang/IllegalStateException", "<init>", "(Ljava/lang/String;)V", false));
                    repl.add(new InsnNode(ATHROW));
                    m.instructions.insertBefore(start, repl);
                    AbstractInsnNode cur = start;
                    while (cur != null) {
                        AbstractInsnNode next = cur.getNext();
                        m.instructions.remove(cur);
                        if (cur == end) break;
                        cur = next;
                    }
                    patched = true;
                    break;
                }
            }
        }
        if (!patched) throw new IllegalStateException("recursive impossible-relock path not found in " + owner);
        SafeClassWriter cw = new SafeClassWriter(ClassWriter.COMPUTE_FRAMES | ClassWriter.COMPUTE_MAXS);
        cn.accept(cw);
        return cw.toByteArray();
    }

    static void emitDelegateCodecCall(InsnList il, String owner, boolean encode) {
        il.add(new VarInsnNode(ALOAD,0)); il.add(new FieldInsnNode(GETFIELD,owner,"delegate","Lcom/mojang/serialization/Codec;"));
        if (encode) {
            il.add(new VarInsnNode(ALOAD,1)); il.add(new VarInsnNode(ALOAD,2)); il.add(new VarInsnNode(ALOAD,3));
            il.add(new MethodInsnNode(INVOKEINTERFACE,"com/mojang/serialization/Codec","encode","(Ljava/lang/Object;Lcom/mojang/serialization/DynamicOps;Ljava/lang/Object;)Lcom/mojang/serialization/DataResult;",true));
        } else {
            il.add(new VarInsnNode(ALOAD,1)); il.add(new VarInsnNode(ALOAD,2));
            il.add(new MethodInsnNode(INVOKEINTERFACE,"com/mojang/serialization/Codec","decode","(Lcom/mojang/serialization/DynamicOps;Ljava/lang/Object;)Lcom/mojang/serialization/DataResult;",true));
        }
    }

    static void emitManagedUnlock(InsnList il, String owner, int blockerLocal, LabelNode skip) {
        il.add(new VarInsnNode(ALOAD,blockerLocal)); il.add(new FieldInsnNode(GETFIELD,owner+"$ManagedLocker","hasLock","Z")); il.add(new JumpInsnNode(IFEQ,skip));
        il.add(new VarInsnNode(ALOAD,0)); il.add(new FieldInsnNode(GETFIELD,owner,"lock","Ljava/util/concurrent/locks/ReentrantLock;")); il.add(new MethodInsnNode(INVOKEVIRTUAL,"java/util/concurrent/locks/ReentrantLock","unlock","()V",false));
    }

    static void emitNormalUnlock(InsnList il, String owner, LabelNode skip) {
        il.add(new VarInsnNode(ALOAD,0)); il.add(new FieldInsnNode(GETFIELD,owner,"lock","Ljava/util/concurrent/locks/ReentrantLock;")); il.add(new MethodInsnNode(INVOKEVIRTUAL,"java/util/concurrent/locks/ReentrantLock","isHeldByCurrentThread","()Z",false)); il.add(new JumpInsnNode(IFEQ,skip));
        il.add(new VarInsnNode(ALOAD,0)); il.add(new FieldInsnNode(GETFIELD,owner,"lock","Ljava/util/concurrent/locks/ReentrantLock;")); il.add(new MethodInsnNode(INVOKEVIRTUAL,"java/util/concurrent/locks/ReentrantLock","unlock","()V",false));
    }

    static byte[] patchManagedLocker(byte[] in) {
        ClassNode cn = new ClassNode(); new ClassReader(in).accept(cn,0); boolean patched=false;
        for (MethodNode m : cn.methods) {
            if (!m.name.equals("block") || !m.desc.equals("()Z")) continue;
            m.instructions.clear(); m.tryCatchBlocks.clear(); m.localVariables=null;
            InsnList il=m.instructions; LabelNode already=new LabelNode();
            il.add(new VarInsnNode(ALOAD,0)); il.add(new FieldInsnNode(GETFIELD,cn.name,"hasLock","Z")); il.add(new JumpInsnNode(IFNE,already));
            il.add(new VarInsnNode(ALOAD,0)); il.add(new FieldInsnNode(GETFIELD,cn.name,"this$0","Lcom/ishland/c2me/fixes/chunkio/threading_issues/common/SynchronizedCodec;"));
            il.add(new FieldInsnNode(GETFIELD,"com/ishland/c2me/fixes/chunkio/threading_issues/common/SynchronizedCodec","lock","Ljava/util/concurrent/locks/ReentrantLock;"));
            il.add(new MethodInsnNode(INVOKEVIRTUAL,"java/util/concurrent/locks/ReentrantLock","lockInterruptibly","()V",false));
            il.add(new VarInsnNode(ALOAD,0)); il.add(new InsnNode(ICONST_1)); il.add(new FieldInsnNode(PUTFIELD,cn.name,"hasLock","Z"));
            il.add(already); il.add(new InsnNode(ICONST_1)); il.add(new InsnNode(IRETURN));
            m.maxLocals=1; m.maxStack=2; patched=true; break;
        }
        if(!patched) throw new IllegalStateException("SynchronizedCodec.ManagedLocker.block not found");
        SafeClassWriter cw=new SafeClassWriter(ClassWriter.COMPUTE_FRAMES|ClassWriter.COMPUTE_MAXS); cn.accept(cw); return cw.toByteArray();
    }

    static byte[] patchFlagMatrixOptimistic(byte[] in) {
        ClassNode cn = new ClassNode();
        new ClassReader(in).accept(cn, 0);
        MethodNode m = null;
        for (MethodNode x : cn.methods) {
            if (x.name.equals("m_230174_") && x.desc.equals("(IIII)V")) { m = x; break; }
        }
        if (m == null) throw new IllegalStateException("ConcurrentFlagMatrix set-if method not found");
        m.instructions.clear();
        m.tryCatchBlocks.clear();
        m.localVariables = null;
        InsnList il = m.instructions;
        LabelNode done = new LabelNode();
        LabelNode writeStart = new LabelNode();
        LabelNode writeEnd = new LabelNode();
        LabelNode handler = new LabelNode();

        // Cheap read-lock early-out. This preserves stock behavior when expected does not match.
        il.add(new VarInsnNode(ALOAD, 0));
        il.add(new VarInsnNode(ILOAD, 1));
        il.add(new VarInsnNode(ILOAD, 2));
        il.add(new MethodInsnNode(INVOKEVIRTUAL, cn.name, "m_230167_", "(II)I", false));
        il.add(new VarInsnNode(ILOAD, 3));
        il.add(new JumpInsnNode(IF_ICMPNE, done));

        // Upgrade by releasing the read lock (already done by m_230167_) and acquiring write.
        il.add(new VarInsnNode(ALOAD, 0));
        il.add(new FieldInsnNode(GETFIELD, cn.name, "rwLock", "Ljava/util/concurrent/locks/ReentrantReadWriteLock;"));
        il.add(new MethodInsnNode(INVOKEVIRTUAL, "java/util/concurrent/locks/ReentrantReadWriteLock", "writeLock", "()Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;", false));
        il.add(new MethodInsnNode(INVOKEVIRTUAL, "java/util/concurrent/locks/ReentrantReadWriteLock$WriteLock", "lock", "()V", false));
        il.add(writeStart);

        // Recheck under the exclusive lock, then call the superclass directly so we do not nest locks.
        il.add(new VarInsnNode(ALOAD, 0));
        il.add(new VarInsnNode(ILOAD, 1));
        il.add(new VarInsnNode(ILOAD, 2));
        il.add(new MethodInsnNode(INVOKESPECIAL, "net/minecraft/world/level/levelgen/structure/structures/WoodlandMansionPieces$SimpleGrid", "m_230167_", "(II)I", false));
        il.add(new VarInsnNode(ILOAD, 3));
        il.add(new JumpInsnNode(IF_ICMPNE, writeEnd));
        il.add(new VarInsnNode(ALOAD, 0));
        il.add(new VarInsnNode(ILOAD, 1));
        il.add(new VarInsnNode(ILOAD, 2));
        il.add(new VarInsnNode(ILOAD, 4));
        il.add(new MethodInsnNode(INVOKESPECIAL, "net/minecraft/world/level/levelgen/structure/structures/WoodlandMansionPieces$SimpleGrid", "m_230170_", "(III)V", false));
        il.add(writeEnd);
        unlockWrite(il, cn.name);
        il.add(new JumpInsnNode(GOTO, done));

        il.add(handler);
        il.add(new VarInsnNode(ASTORE, 5));
        unlockWrite(il, cn.name);
        il.add(new VarInsnNode(ALOAD, 5));
        il.add(new InsnNode(ATHROW));

        il.add(done);
        il.add(new InsnNode(RETURN));
        m.tryCatchBlocks.add(new TryCatchBlockNode(writeStart, writeEnd, handler, null));
        m.maxLocals = 6;
        m.maxStack = 5;
        SafeClassWriter cw = new SafeClassWriter(ClassWriter.COMPUTE_FRAMES | ClassWriter.COMPUTE_MAXS);
        cn.accept(cw);
        return cw.toByteArray();
    }

    private static void unlockWrite(InsnList il, String owner) {
        il.add(new VarInsnNode(ALOAD, 0));
        il.add(new FieldInsnNode(GETFIELD, owner, "rwLock", "Ljava/util/concurrent/locks/ReentrantReadWriteLock;"));
        il.add(new MethodInsnNode(INVOKEVIRTUAL, "java/util/concurrent/locks/ReentrantReadWriteLock", "writeLock", "()Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;", false));
        il.add(new MethodInsnNode(INVOKEVIRTUAL, "java/util/concurrent/locks/ReentrantReadWriteLock$WriteLock", "unlock", "()V", false));
    }


    static byte[] patchSynchronizedCodecFast(byte[] in) {
        ClassNode cn = new ClassNode();
        new ClassReader(in).accept(cn, 0);
        boolean decode = false, encode = false;
        for (MethodNode m : cn.methods) {
            if (m.name.equals("decode") && m.desc.equals("(Lcom/mojang/serialization/DynamicOps;Ljava/lang/Object;)Lcom/mojang/serialization/DataResult;")) {
                rewriteCodecMethodFast(cn.name, m, false); decode = true;
            } else if (m.name.equals("encode") && m.desc.equals("(Ljava/lang/Object;Lcom/mojang/serialization/DynamicOps;Ljava/lang/Object;)Lcom/mojang/serialization/DataResult;")) {
                rewriteCodecMethodFast(cn.name, m, true); encode = true;
            }
        }
        if (!decode || !encode) throw new IllegalStateException("SynchronizedCodec methods not found");
        SafeClassWriter cw = new SafeClassWriter(ClassWriter.COMPUTE_FRAMES | ClassWriter.COMPUTE_MAXS);
        cn.accept(cw);
        return cw.toByteArray();
    }

    static void rewriteCodecMethodFast(String owner, MethodNode m, boolean encode) {
        m.instructions.clear();
        m.tryCatchBlocks.clear();
        m.localVariables = null;
        InsnList il = m.instructions;
        int blockerLocal = encode ? 4 : 3;
        int resultLocal = encode ? 5 : 4;
        int throwableLocal = encode ? 6 : 5;
        int interruptedLocal = encode ? 7 : 6;

        LabelNode normalPath = new LabelNode();
        LabelNode managedPath = new LabelNode();
        LabelNode fastStart = new LabelNode(), fastEnd = new LabelNode(), fastCatch = new LabelNode(), fastNoUnlock = new LabelNode();
        LabelNode managedStart = new LabelNode(), managedEnd = new LabelNode(), managedInterrupted = new LabelNode(), managedCatchAll = new LabelNode();
        LabelNode managedNoUnlock = new LabelNode(), managedFinally = new LabelNode(), managedCatchNoUnlock = new LabelNode();
        LabelNode normalStart = new LabelNode(), normalEnd = new LabelNode(), normalInterrupted = new LabelNode(), normalCatchAll = new LabelNode();
        LabelNode normalNoUnlock = new LabelNode(), normalIntNoUnlock = new LabelNode(), normalCatchNoUnlock = new LabelNode();

        // ForkJoin workers: preserve stock-cost behavior when the codec lock is free.
        il.add(new MethodInsnNode(INVOKESTATIC, "java/lang/Thread", "currentThread", "()Ljava/lang/Thread;", false));
        il.add(new TypeInsnNode(INSTANCEOF, "java/util/concurrent/ForkJoinWorkerThread"));
        il.add(new JumpInsnNode(IFEQ, normalPath));
        il.add(new VarInsnNode(ALOAD, 0));
        il.add(new FieldInsnNode(GETFIELD, owner, "lock", "Ljava/util/concurrent/locks/ReentrantLock;"));
        il.add(new MethodInsnNode(INVOKEVIRTUAL, "java/util/concurrent/locks/ReentrantLock", "tryLock", "()Z", false));
        il.add(new JumpInsnNode(IFEQ, managedPath));

        // Uncontended ForkJoin fast path: no blocker allocation or managedBlock call.
        il.add(fastStart);
        emitDelegateCodecCall(il, owner, encode);
        il.add(new VarInsnNode(ASTORE, resultLocal));
        il.add(fastEnd);
        emitNormalUnlock(il, owner, fastNoUnlock);
        il.add(fastNoUnlock);
        il.add(new VarInsnNode(ALOAD, resultLocal));
        il.add(new InsnNode(ARETURN));
        il.add(fastCatch);
        il.add(new VarInsnNode(ASTORE, throwableLocal));
        LabelNode fastCatchNoUnlock = new LabelNode();
        emitNormalUnlock(il, owner, fastCatchNoUnlock);
        il.add(fastCatchNoUnlock);
        il.add(new VarInsnNode(ALOAD, throwableLocal));
        il.add(new InsnNode(ATHROW));

        // Contended ForkJoin path: tell the pool it may compensate for this blocking lock wait.
        il.add(managedPath);
        il.add(new TypeInsnNode(NEW, owner + "$ManagedLocker"));
        il.add(new InsnNode(DUP));
        il.add(new VarInsnNode(ALOAD, 0));
        il.add(new MethodInsnNode(INVOKESPECIAL, owner + "$ManagedLocker", "<init>", "(L" + owner + ";)V", false));
        il.add(new VarInsnNode(ASTORE, blockerLocal));
        il.add(managedStart);
        il.add(new VarInsnNode(ALOAD, blockerLocal));
        il.add(new MethodInsnNode(INVOKESTATIC, "java/util/concurrent/ForkJoinPool", "managedBlock", "(Ljava/util/concurrent/ForkJoinPool$ManagedBlocker;)V", false));
        emitDelegateCodecCall(il, owner, encode);
        il.add(new VarInsnNode(ASTORE, resultLocal));
        il.add(managedEnd);
        emitManagedUnlock(il, owner, blockerLocal, managedNoUnlock);
        il.add(managedNoUnlock);
        il.add(new VarInsnNode(ALOAD, resultLocal));
        il.add(new InsnNode(ARETURN));
        il.add(managedInterrupted);
        il.add(new VarInsnNode(ASTORE, interruptedLocal));
        il.add(new MethodInsnNode(INVOKESTATIC, "java/lang/Thread", "currentThread", "()Ljava/lang/Thread;", false));
        il.add(new MethodInsnNode(INVOKEVIRTUAL, "java/lang/Thread", "interrupt", "()V", false));
        il.add(new TypeInsnNode(NEW, "java/lang/RuntimeException"));
        il.add(new InsnNode(DUP));
        il.add(new VarInsnNode(ALOAD, interruptedLocal));
        il.add(new MethodInsnNode(INVOKESPECIAL, "java/lang/RuntimeException", "<init>", "(Ljava/lang/Throwable;)V", false));
        il.add(new VarInsnNode(ASTORE, throwableLocal));
        emitManagedUnlock(il, owner, blockerLocal, managedFinally);
        il.add(managedFinally);
        il.add(new VarInsnNode(ALOAD, throwableLocal));
        il.add(new InsnNode(ATHROW));
        il.add(managedCatchAll);
        il.add(new VarInsnNode(ASTORE, throwableLocal));
        emitManagedUnlock(il, owner, blockerLocal, managedCatchNoUnlock);
        il.add(managedCatchNoUnlock);
        il.add(new VarInsnNode(ALOAD, throwableLocal));
        il.add(new InsnNode(ATHROW));

        // Non-ForkJoin threads retain stock interruptible-lock semantics.
        il.add(normalPath);
        il.add(normalStart);
        il.add(new VarInsnNode(ALOAD, 0));
        il.add(new FieldInsnNode(GETFIELD, owner, "lock", "Ljava/util/concurrent/locks/ReentrantLock;"));
        il.add(new MethodInsnNode(INVOKEVIRTUAL, "java/util/concurrent/locks/ReentrantLock", "lockInterruptibly", "()V", false));
        emitDelegateCodecCall(il, owner, encode);
        il.add(new VarInsnNode(ASTORE, resultLocal));
        il.add(normalEnd);
        emitNormalUnlock(il, owner, normalNoUnlock);
        il.add(normalNoUnlock);
        il.add(new VarInsnNode(ALOAD, resultLocal));
        il.add(new InsnNode(ARETURN));
        il.add(normalInterrupted);
        il.add(new VarInsnNode(ASTORE, interruptedLocal));
        il.add(new MethodInsnNode(INVOKESTATIC, "java/lang/Thread", "currentThread", "()Ljava/lang/Thread;", false));
        il.add(new MethodInsnNode(INVOKEVIRTUAL, "java/lang/Thread", "interrupt", "()V", false));
        il.add(new TypeInsnNode(NEW, "java/lang/RuntimeException"));
        il.add(new InsnNode(DUP));
        il.add(new VarInsnNode(ALOAD, interruptedLocal));
        il.add(new MethodInsnNode(INVOKESPECIAL, "java/lang/RuntimeException", "<init>", "(Ljava/lang/Throwable;)V", false));
        il.add(new VarInsnNode(ASTORE, throwableLocal));
        emitNormalUnlock(il, owner, normalIntNoUnlock);
        il.add(normalIntNoUnlock);
        il.add(new VarInsnNode(ALOAD, throwableLocal));
        il.add(new InsnNode(ATHROW));
        il.add(normalCatchAll);
        il.add(new VarInsnNode(ASTORE, throwableLocal));
        emitNormalUnlock(il, owner, normalCatchNoUnlock);
        il.add(normalCatchNoUnlock);
        il.add(new VarInsnNode(ALOAD, throwableLocal));
        il.add(new InsnNode(ATHROW));

        m.tryCatchBlocks.add(new TryCatchBlockNode(fastStart, fastEnd, fastCatch, null));
        m.tryCatchBlocks.add(new TryCatchBlockNode(managedStart, managedEnd, managedInterrupted, "java/lang/InterruptedException"));
        m.tryCatchBlocks.add(new TryCatchBlockNode(managedStart, managedEnd, managedCatchAll, null));
        m.tryCatchBlocks.add(new TryCatchBlockNode(normalStart, normalEnd, normalInterrupted, "java/lang/InterruptedException"));
        m.tryCatchBlocks.add(new TryCatchBlockNode(normalStart, normalEnd, normalCatchAll, null));
        m.maxLocals = interruptedLocal + 1;
        m.maxStack = 8;
    }

    public static void main(String[] args) throws Exception {
        if (args.length != 2) throw new IllegalArgumentException("usage: input.jar output.jar");
        Path in = Path.of(args[0]), out = Path.of(args[1]);
        Set<String> touched = new LinkedHashSet<>();
        try (JarFile jf = new JarFile(in.toFile()); JarOutputStream jos = new JarOutputStream(Files.newOutputStream(out))) {
            Enumeration<JarEntry> en = jf.entries();
            while (en.hasMoreElements()) {
                JarEntry e = en.nextElement();
                String name = e.getName();
                if (name.equals(OLD_HELPER) || name.equals(OLD_MARKER) || name.equals(MARKER)) continue;
                byte[] bytes;
                try (InputStream is = jf.getInputStream(e)) { bytes = is.readAllBytes(); }
                if (name.equals(ASYNC_LOCK)) {
                    bytes = patchImpossibleRelockRecursion(bytes, "com/ishland/c2me/base/common/util/AsyncCombinedLock", "()V");
                    touched.add(name);
                } else if (name.equals(SCHED_LOCK)) {
                    bytes = patchImpossibleRelockRecursion(bytes, "com/ishland/c2me/base/common/scheduler/SchedulingAsyncCombinedLock", "()Z");
                    touched.add(name);
                } else if (name.equals(FLAG_MATRIX)) {
                    bytes = patchFlagMatrixOptimistic(bytes); touched.add(name);
                } else if (name.equals(SYNC_CODEC)) {
                    bytes = patchSynchronizedCodecFast(bytes); touched.add(name);
                } else if (name.equals(SYNC_LOCKER)) {
                    bytes = patchManagedLocker(bytes); touched.add(name);
                }
                JarEntry ne = new JarEntry(name); ne.setTime(e.getTime()); jos.putNextEntry(ne);
                if (!e.isDirectory()) jos.write(bytes);
                jos.closeEntry();
            }
            if (touched.size() != 5) throw new IllegalStateException("Expected five patched classes, got " + touched);
            JarEntry marker = new JarEntry(MARKER); marker.setTime(0L); jos.putNextEntry(marker);
            jos.write(("Noxviola C2ME performance-safe hardening v3 for 0.2.0-forge.9\n"+
                "Base SHA-256: 1e4a4b1f1eb263f15727be5c385c6f3caa09a732ba2d66d4e5ae961f91a22eb5\n"+
                "- keeps upstream combined-lock acquisition order: tryLock never blocks while partial locks are held\n"+
                "- impossible relock recursion fails fast instead of recursing\n"+
                "- ConcurrentFlagMatrix set-if uses read-fast/write-recheck atomic update\n"+
                "- ForkJoin codec locking uses uncontended tryLock fast path; ManagedBlocker only on contention, with interrupt preservation\n"+
                "- no scheduler timing, storage, queue, pool, adaptive-controller, mid-tick, or DimThread guard changes\n").getBytes(StandardCharsets.UTF_8));
            jos.closeEntry();
        }
    }
}
