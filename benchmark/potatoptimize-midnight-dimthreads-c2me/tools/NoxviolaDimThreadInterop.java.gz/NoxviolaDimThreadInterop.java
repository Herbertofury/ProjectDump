package com.ishland.c2me.noxviola;

/**
 * Compatibility bridge for C2ME's injected off-thread chunk check when DimThread 1.2.1
 * is actively ticking worlds. DimThread.owns(Thread) in the verified 1.2.1 target is
 * exactly a name-prefix test for "dimthread_server_". During a DimThread world tick,
 * its own ServerChunkCache mixin substitutes the cache's declared main thread whenever
 * the current worker is owned by DimThread. C2ME's HEAD injection executes outside that
 * wrapped call site, so it must mirror the same ownership classification.
 */
public final class NoxviolaDimThreadInterop {
    private static final String DIMTHREAD_PREFIX = "dimthread_server_";

    private NoxviolaDimThreadInterop() {}

    public static boolean isEffectivelyMain(Thread current, Thread declaredMain) {
        if (current == declaredMain) return true;
        return current != null && current.getName().startsWith(DIMTHREAD_PREFIX);
    }
}
