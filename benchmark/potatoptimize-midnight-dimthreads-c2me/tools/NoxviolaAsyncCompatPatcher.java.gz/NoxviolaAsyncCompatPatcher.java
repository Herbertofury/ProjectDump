package noxviola.repair;

import jdk.internal.org.objectweb.asm.*;
import jdk.internal.org.objectweb.asm.tree.*;

import java.io.*;
import java.nio.file.*;
import java.security.MessageDigest;
import java.util.*;
import java.util.jar.*;
import java.util.zip.*;

/**
 * Noxviola 1.20.1 async compatibility patcher.
 *
 * Production modes:
 *   c2me <input.jar> <output.jar> <interop-helper.class>
 *   midnight <input.jar> <output.jar>
 *
 * Test-only modes append --structural-test to bypass the exact C2ME stock-JAR hash gate.
 */
public final class NoxviolaAsyncCompatPatcher implements Opcodes {
    private static final String STOCK_C2ME_SHA256 = "1e4a4b1f1eb263f15727be5c385c6f3caa09a732ba2d66d4e5ae961f91a22eb5";
    private static final String C2ME_MIXIN = "com/ishland/c2me/opts/chunk_access/mixin/async_chunk_request/MixinServerChunkManager.class";
    private static final String C2ME_HELPER = "com/ishland/c2me/noxviola/NoxviolaDimThreadInterop.class";
    private static final String C2ME_MARKER = "META-INF/noxviola-c2me-dimthread-interop-v4.txt";
    private static final String MIDNIGHT_CLASS = "com/crypticmushroom/minecraft/midnight/Midnight.class";
    private static final String MIDNIGHT_MARKER = "META-INF/noxviola-midnight-rift-threadsafe-v1.txt";

    private NoxviolaAsyncCompatPatcher() {}

    public static void main(String[] args) throws Exception {
        if (args.length < 3) usage();
        boolean structuralTest = Arrays.asList(args).contains("--structural-test");
        String mode = args[0];
        Path in = Paths.get(args[1]).toAbsolutePath();
        Path out = Paths.get(args[2]).toAbsolutePath();
        if (!Files.isRegularFile(in)) fail("Input JAR does not exist: " + in);
        if (in.equals(out)) fail("Refusing in-place mutation; input and output must differ");
        if (hasSignatures(in)) fail("Input contains JAR signatures; refusing to invalidate signatures");
        Files.createDirectories(out.getParent());

        switch (mode) {
            case "c2me" -> {
                if (args.length < 4) usage();
                Path helper = Paths.get(args[3]).toAbsolutePath();
                if (!Files.isRegularFile(helper)) fail("Missing compiled interop helper: " + helper);
                patchC2ME(in, out, helper, structuralTest);
            }
            case "midnight" -> patchMidnight(in, out);
            default -> usage();
        }
    }

    private static void patchC2ME(Path in, Path out, Path helperClass, boolean structuralTest) throws Exception {
        String inputHash = sha256(in);
        if (!structuralTest && !inputHash.equals(STOCK_C2ME_SHA256)) {
            fail("C2ME input hash mismatch. Expected exact stock forge.9 " + STOCK_C2ME_SHA256 + " but got " + inputHash + ". Refusing to patch an unknown build.");
        }
        byte[] helper = Files.readAllBytes(helperClass);
        assertJava17Class(helper, "interop helper");
        Map<String, byte[]> entries = readJar(in);
        if (entries.containsKey(C2ME_MARKER)) fail("C2ME input is already marked as Noxviola v4 patched");
        byte[] target = entries.get(C2ME_MIXIN);
        if (target == null) fail("C2ME target class missing: " + C2ME_MIXIN);

        ClassNode cn = new ClassNode();
        new ClassReader(target).accept(cn, 0);
        MethodNode method = null;
        for (MethodNode m : cn.methods) {
            if (m.name.equals("onGetChunk") && m.desc.equals("(IILnet/minecraft/world/level/chunk/ChunkStatus;ZLorg/spongepowered/asm/mixin/injection/callback/CallbackInfoReturnable;)V")) {
                if (method != null) fail("Multiple C2ME onGetChunk targets found");
                method = m;
            }
        }
        if (method == null) fail("Expected C2ME onGetChunk method not found");

        int patched = 0;
        for (AbstractInsnNode n = method.instructions.getFirst(); n != null; n = n.getNext()) {
            if (!(n instanceof MethodInsnNode mi) || mi.getOpcode() != INVOKESTATIC
                    || !mi.owner.equals("java/lang/Thread") || !mi.name.equals("currentThread")
                    || !mi.desc.equals("()Ljava/lang/Thread;")) continue;

            AbstractInsnNode a = nextReal(n);
            AbstractInsnNode f = nextReal(a);
            AbstractInsnNode j = nextReal(f);
            if (!(a instanceof VarInsnNode vi) || vi.getOpcode() != ALOAD || vi.var != 0) continue;
            if (!(f instanceof FieldInsnNode fi) || fi.getOpcode() != GETFIELD || !fi.name.equals("f_8330_") || !fi.desc.equals("Ljava/lang/Thread;")) continue;
            if (!(j instanceof JumpInsnNode ji) || ji.getOpcode() != IF_ACMPEQ) continue;

            method.instructions.insertBefore(ji, new MethodInsnNode(INVOKESTATIC,
                    "com/ishland/c2me/noxviola/NoxviolaDimThreadInterop",
                    "isEffectivelyMain",
                    "(Ljava/lang/Thread;Ljava/lang/Thread;)Z",
                    false));
            ji.setOpcode(IFNE);
            patched++;
        }
        if (patched != 1) fail("C2ME structural gate failed: expected exactly one main-thread comparison, found " + patched);

        ClassWriter cw = new ClassWriter(0);
        cn.accept(cw);
        byte[] patchedClass = cw.toByteArray();
        assertJava17Class(patchedClass, "patched C2ME mixin");
        entries.put(C2ME_MIXIN, patchedClass);
        entries.put(C2ME_HELPER, helper);
        entries.put(C2ME_MARKER, ("Noxviola C2ME <-> DimThread interop v4\n" +
                "input_sha256=" + inputHash + "\n" +
                "change=Treat verified DimThread 1.2.1 worker threads as effective main threads in C2ME getChunk HEAD injection.\n").getBytes(java.nio.charset.StandardCharsets.UTF_8));
        writeJar(in, out, entries);
        verifyC2MEOutput(out);
        System.out.println("C2ME_PATCH_OK input_sha256=" + inputHash + " output_sha256=" + sha256(out));
    }

    private static void verifyC2MEOutput(Path out) throws Exception {
        Map<String, byte[]> entries = readJar(out);
        byte[] target = entries.get(C2ME_MIXIN);
        if (target == null || !entries.containsKey(C2ME_HELPER) || !entries.containsKey(C2ME_MARKER)) fail("C2ME post-write entry verification failed");
        ClassNode cn = new ClassNode();
        new ClassReader(target).accept(cn, 0);
        int helperCalls = 0, oldBranches = 0, offThreadCalls = 0;
        for (MethodNode m : cn.methods) if (m.name.equals("onGetChunk")) {
            for (AbstractInsnNode n = m.instructions.getFirst(); n != null; n = n.getNext()) {
                if (n instanceof MethodInsnNode mi) {
                    if (mi.owner.equals("com/ishland/c2me/noxviola/NoxviolaDimThreadInterop") && mi.name.equals("isEffectivelyMain")) helperCalls++;
                    if (mi.name.equals("c2me$getChunkOffThread")) offThreadCalls++;
                } else if (n instanceof JumpInsnNode ji && ji.getOpcode() == IF_ACMPEQ) oldBranches++;
            }
        }
        if (helperCalls != 1 || oldBranches != 0 || offThreadCalls != 1) {
            fail("C2ME post-write bytecode gate failed: helperCalls=" + helperCalls + " oldBranches=" + oldBranches + " offThreadCalls=" + offThreadCalls);
        }
    }

    private static void patchMidnight(Path in, Path out) throws Exception {
        String inputHash = sha256(in);
        Map<String, byte[]> entries = readJar(in);
        if (entries.containsKey(MIDNIGHT_MARKER)) fail("Midnight input is already marked as Noxviola RiftThreadSafe patched");
        byte[] target = entries.get(MIDNIGHT_CLASS);
        if (target == null) fail("Midnight target class missing: " + MIDNIGHT_CLASS);
        byte[] beforeCodeFingerprint = methodCodeFingerprint(target, "onLevelTick");

        ClassNode cn = new ClassNode();
        new ClassReader(target).accept(cn, 0);
        MethodNode targetMethod = null;
        for (MethodNode m : cn.methods) {
            if (!m.name.equals("onLevelTick")) continue;
            if ((m.access & ACC_STATIC) == 0) continue;
            if ((m.access & (ACC_ABSTRACT | ACC_NATIVE)) != 0) fail("Midnight onLevelTick is abstract/native unexpectedly");
            if (targetMethod != null) fail("Multiple static Midnight.onLevelTick methods found; refusing ambiguous patch");
            targetMethod = m;
        }
        if (targetMethod == null) fail("Static Midnight.onLevelTick method not found");
        if ((targetMethod.access & ACC_SYNCHRONIZED) != 0) fail("Midnight.onLevelTick is already synchronized");
        targetMethod.access |= ACC_SYNCHRONIZED;

        ClassWriter cw = new ClassWriter(0);
        cn.accept(cw);
        byte[] patchedClass = cw.toByteArray();
        assertJava17Class(patchedClass, "patched Midnight class");
        byte[] afterCodeFingerprint = methodCodeFingerprint(patchedClass, "onLevelTick");
        if (!Arrays.equals(beforeCodeFingerprint, afterCodeFingerprint)) fail("Midnight code fingerprint changed; expected access-flag-only patch");

        entries.put(MIDNIGHT_CLASS, patchedClass);
        entries.put(MIDNIGHT_MARKER, ("Noxviola Midnight Rift tracker thread-safety v1\n" +
                "input_sha256=" + inputHash + "\n" +
                "change=ACC_SYNCHRONIZED on static Midnight.onLevelTick only; method code unchanged.\n").getBytes(java.nio.charset.StandardCharsets.UTF_8));
        writeJar(in, out, entries);
        verifyMidnightOutput(out);
        System.out.println("MIDNIGHT_PATCH_OK input_sha256=" + inputHash + " output_sha256=" + sha256(out));
    }

    private static void verifyMidnightOutput(Path out) throws Exception {
        Map<String, byte[]> entries = readJar(out);
        byte[] target = entries.get(MIDNIGHT_CLASS);
        if (target == null || !entries.containsKey(MIDNIGHT_MARKER)) fail("Midnight post-write entry verification failed");
        ClassNode cn = new ClassNode();
        new ClassReader(target).accept(cn, 0);
        int count = 0;
        for (MethodNode m : cn.methods) if (m.name.equals("onLevelTick") && (m.access & ACC_STATIC) != 0) {
            count++;
            if ((m.access & ACC_SYNCHRONIZED) == 0) fail("Midnight.onLevelTick did not retain ACC_SYNCHRONIZED");
        }
        if (count != 1) fail("Midnight post-write method count mismatch: " + count);
    }

    // Fingerprint only opcode/operand structure for the named method(s), intentionally excluding access flags.
    private static byte[] methodCodeFingerprint(byte[] classBytes, String methodName) throws Exception {
        ClassNode cn = new ClassNode();
        new ClassReader(classBytes).accept(cn, 0);
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        int count = 0;
        for (MethodNode m : cn.methods) {
            if (!m.name.equals(methodName)) continue;
            count++;
            update(md, m.name); update(md, m.desc);
            for (AbstractInsnNode n = m.instructions.getFirst(); n != null; n = n.getNext()) {
                md.update((byte)n.getType());
                int op = n.getOpcode(); md.update((byte)(op & 0xff)); md.update((byte)((op >>> 8) & 0xff));
                if (n instanceof IntInsnNode x) update(md, Integer.toString(x.operand));
                else if (n instanceof VarInsnNode x) update(md, Integer.toString(x.var));
                else if (n instanceof TypeInsnNode x) update(md, x.desc);
                else if (n instanceof FieldInsnNode x) { update(md,x.owner); update(md,x.name); update(md,x.desc); }
                else if (n instanceof MethodInsnNode x) { update(md,x.owner); update(md,x.name); update(md,x.desc); update(md,Boolean.toString(x.itf)); }
                else if (n instanceof LdcInsnNode x) update(md, String.valueOf(x.cst));
                else if (n instanceof IincInsnNode x) { update(md,Integer.toString(x.var)); update(md,Integer.toString(x.incr)); }
                else if (n instanceof MultiANewArrayInsnNode x) { update(md,x.desc); update(md,Integer.toString(x.dims)); }
                // Labels/jump destinations/frame objects are intentionally excluded; code/opcode shape is retained by this patch.
            }
        }
        if (count != 1) fail("Expected exactly one method named " + methodName + " for fingerprint, got " + count);
        return md.digest();
    }

    private static void update(MessageDigest md, String s) {
        md.update(s.getBytes(java.nio.charset.StandardCharsets.UTF_8)); md.update((byte)0);
    }

    private static AbstractInsnNode nextReal(AbstractInsnNode n) {
        if (n == null) return null;
        n = n.getNext();
        while (n != null && (n.getType() == AbstractInsnNode.LABEL || n.getType() == AbstractInsnNode.LINE || n.getType() == AbstractInsnNode.FRAME)) n = n.getNext();
        return n;
    }

    private static Map<String, byte[]> readJar(Path jar) throws IOException {
        LinkedHashMap<String, byte[]> out = new LinkedHashMap<>();
        try (JarFile jf = new JarFile(jar.toFile(), false)) {
            Enumeration<JarEntry> en = jf.entries();
            while (en.hasMoreElements()) {
                JarEntry e = en.nextElement();
                try (InputStream is = jf.getInputStream(e)) { out.put(e.getName(), is.readAllBytes()); }
            }
        }
        return out;
    }

    private static void writeJar(Path templateJar, Path out, Map<String, byte[]> contents) throws IOException {
        Path tmp = out.resolveSibling(out.getFileName() + ".tmp");
        Files.deleteIfExists(tmp);
        Set<String> written = new HashSet<>();
        try (JarFile template = new JarFile(templateJar.toFile(), false);
             JarOutputStream jos = new JarOutputStream(new BufferedOutputStream(Files.newOutputStream(tmp)))) {
            Enumeration<JarEntry> en = template.entries();
            while (en.hasMoreElements()) {
                JarEntry old = en.nextElement();
                String name = old.getName();
                byte[] data = contents.get(name);
                if (data == null) fail("Internal write map lost entry " + name);
                JarEntry ne = cloneEntry(old, data);
                jos.putNextEntry(ne); jos.write(data); jos.closeEntry(); written.add(name);
            }
            for (Map.Entry<String, byte[]> e : contents.entrySet()) {
                if (written.contains(e.getKey())) continue;
                JarEntry ne = new JarEntry(e.getKey());
                ne.setTime(0L);
                jos.putNextEntry(ne); jos.write(e.getValue()); jos.closeEntry();
            }
        } catch (Throwable t) {
            Files.deleteIfExists(tmp);
            throw t;
        }
        try (JarFile jf = new JarFile(tmp.toFile(), false)) {
            Enumeration<JarEntry> en = jf.entries();
            while (en.hasMoreElements()) {
                JarEntry e = en.nextElement();
                try (InputStream is = jf.getInputStream(e)) { while (is.read(new byte[8192]) != -1) {} }
            }
        }
        try {
            Files.move(tmp, out, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
        } catch (AtomicMoveNotSupportedException e) {
            Files.move(tmp, out, StandardCopyOption.REPLACE_EXISTING);
        }
    }

    private static JarEntry cloneEntry(JarEntry old, byte[] data) {
        JarEntry ne = new JarEntry(old.getName());
        if (old.getComment() != null) ne.setComment(old.getComment());
        if (old.getExtra() != null) ne.setExtra(old.getExtra());
        if (old.getTime() >= 0) ne.setTime(old.getTime());
        if (old.getMethod() == ZipEntry.STORED) {
            CRC32 crc = new CRC32(); crc.update(data);
            ne.setMethod(ZipEntry.STORED); ne.setSize(data.length); ne.setCompressedSize(data.length); ne.setCrc(crc.getValue());
        } else ne.setMethod(ZipEntry.DEFLATED);
        return ne;
    }

    private static boolean hasSignatures(Path jar) throws IOException {
        try (JarFile jf = new JarFile(jar.toFile(), false)) {
            Enumeration<JarEntry> en = jf.entries();
            while (en.hasMoreElements()) {
                String n = en.nextElement().getName().toUpperCase(Locale.ROOT);
                if (n.startsWith("META-INF/") && (n.endsWith(".SF") || n.endsWith(".RSA") || n.endsWith(".DSA") || n.endsWith(".EC"))) return true;
            }
        }
        return false;
    }

    private static void assertJava17Class(byte[] b, String what) {
        if (b.length < 8 || b[0] != (byte)0xCA || b[1] != (byte)0xFE || b[2] != (byte)0xBA || b[3] != (byte)0xBE) fail(what + " is not a class file");
        int major = ((b[6] & 0xff) << 8) | (b[7] & 0xff);
        if (major > 61) fail(what + " class major " + major + " is newer than Java 17");
    }

    private static String sha256(Path p) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        try (InputStream in = Files.newInputStream(p)) { byte[] buf = new byte[1 << 16]; for (int n; (n = in.read(buf)) >= 0;) md.update(buf,0,n); }
        return HexFormat.of().formatHex(md.digest());
    }

    private static void fail(String msg) { throw new IllegalStateException(msg); }
    private static void usage() { throw new IllegalArgumentException("Usage: c2me <input.jar> <output.jar> <helper.class> [--structural-test] | midnight <input.jar> <output.jar>"); }
}
